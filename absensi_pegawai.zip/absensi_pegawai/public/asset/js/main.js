$(document).ready(function () {
    const status_login = $('#status_login').data('flashdata');
    if (status_login) {
        swal({
            title: status_login,
            text: "Silahkan Login",
            icon: "success",
            button: "OK"
        })
    }
    const status_eror = $('#status_eror').data('flashdata');
    if (status_eror) {
        swal({
            title: status_eror,
            text: "Silahkan Ulangi",
            icon: "error",
            button: "OK"
        })
    }
    const status_user_login = $('#status_user_login').data('flashdata');
    if (status_user_login) {
        swal({
            title: status_user_login,
            text: "Silahkan Ulangi",
            icon: "error",
            button: "OK"
        })
    }
    const status_file = $('#status_file').data('flashdata');
    if (status_file) {
        swal({
            title: "Data Berhasil",
            text: status_file,
            icon: "success",
            button: "OK"
        })
    }
    const status_profile = $('#status_profile').data('flashdata');
    if (status_profile) {
        swal({
            title: "Password Gagal",
            text: status_profile,
            icon: "error",
            button: "OK"
        })
    }
    const status_profile_pegawai = $('#status_profile_pegawai').data('flashdata');
    if (status_profile_pegawai) {
        swal({
            title: "Password Gagal",
            text: status_profile_pegawai,
            icon: "error",
            button: "OK"
        })
    }
    const status_profile_login = $('#status_profile_login').data('flashdata');
    if (status_profile_login) {
        swal({
            title: status_profile_login,
            text: "Silahkan Login Kembali",
            icon: "success",
            button: "OK"
        })
    }
    const status_email = $('#status_email').data('flashdata');
    if (status_email) {
        swal({
            title: "Email Gagal",
            text: status_email,
            icon: "error",
            button: "OK"
        })
    }
    const status_rename_password = $('#status_rename_password').data('flashdata');
    if (status_rename_password) {
        swal({
            title: "Password Gagal",
            text: status_rename_password,
            icon: "error",
            button: "OK"
        })
    }
    const status_profile_admin = $('#status_profile_admin').data('flashdata');
    if (status_profile_admin) {
        swal({
            title: "Password Berhasil",
            text: status_profile_admin,
            icon: "success",
            button: "OK"
        })
    }
    const slip_gaji = $('#slip_gaji').data('flashdata');
    if (slip_gaji) {
        swal({
            title: "Data Berhasil",
            text: slip_gaji,
            icon: "success",
            button: "OK"
        })
    }
    const status_slip_gaji = $('#status_slip_gaji').data('flashdata');
    if (status_slip_gaji) {
        swal({
            title: "Data Berhasil",
            text: status_slip_gaji,
            icon: "success",
            button: "OK"
        })
    }
    const status_arsip = $('#status_arsip').data('flashdata');
    if (status_arsip) {
        swal({
            title: "Data Berhasil",
            text: status_arsip,
            icon: "success",
            button: "OK"
        })
    }
    const token = $('#token').data('flashdata');
    if (token) {
        swal({
            title: "Data Gagal",
            text: token,
            icon: "error",
            button: "OK"
        })
    }
    const status_token = $('#status_token').data('flashdata');
    if (status_token) {
        swal({
            title: "Data Gagal",
            text: status_token,
            icon: "error",
            button: "OK"
        })
    }

    ClassicEditor
        .create(document.querySelector('#message'))
        .catch(error => {
            console.error(error);
        });


});
