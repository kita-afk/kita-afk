<?php

use App\Http\Controllers\LoginController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', function () {
//     return view('welcome');
// });

//login
Route::get('/', 'LoginController@index')->middleware('login','login_pegawai');
Route::get('/register', 'LoginController@registrer')->middleware('login','login_pegawai');
Route::post('/register_user', 'LoginController@register_user');
Route::post('/login', 'LoginController@login');

// file
Route::get('/dashboard', 'admin\DashboardController@index')->middleware('not_login');
Route::get('/tambah_file', 'admin\DashboardController@tambah_file')->middleware('not_login');
Route::get('/proses_file/{id}', 'admin\DashboardController@proses_file')->middleware('not_login');
Route::get('/approved/{id}', 'admin\DashboardController@approved')->middleware('not_login');
Route::post('/tambah_upload_file', 'admin\DashboardController@tambah_upload_file');
Route::get('/edit_file/{id}', 'admin\DashboardController@edit_file')->middleware('not_login');
Route::post('/edit_upload_file/{id}', 'admin\DashboardController@edit_upload_file');
Route::delete('/hapus_file/{id}', 'admin\DashboardController@hapus_file');

// absensi
Route::get('/absensi', 'admin\DashboardController@absensi')->middleware('not_login');
Route::get('/tambah_absen', 'admin\DashboardController@tambah_absen')->middleware('not_login');
Route::post('/tambah_absensi_pegawai', 'admin\DashboardController@tambah_absensi_pegawai');
Route::get('/edit_absen/{id}', 'admin\DashboardController@edit_absen')->middleware('not_login');
Route::post('/edit_absensi_pegawai/{id}', 'admin\DashboardController@edit_absensi_pegawai');
Route::delete('/hapus_absen_pegawai/{id}', 'admin\DashboardController@hapus_absen_pegawai');
Route::get('/absen_pegawai/{id}', 'admin\DashboardController@absensi_pegawai')->middleware('not_login');
Route::get('/token/{id}', 'admin\DashboardController@token')->middleware('not_login');

//akun
Route::get('/akun', 'admin\DashboardController@akun')->middleware('not_login');
Route::get('/profile/{id}', 'admin\DashboardController@profile_user')->middleware('not_login');
Route::post('/simpan_profile/{id}', 'admin\DashboardController@simpan_profile');

// pegawai
Route::get('/pegawai', 'pegawai\pegawai@index')->middleware('not_login_pegawai');
Route::get('/absensi_user_pegawai/{id}', 'pegawai\pegawai@absensi_user_pegawai')->middleware('not_login_pegawai');
Route::get('/logout/{id}', 'admin\DashboardController@logout');
Route::get('/logout_pegawai/{id}', 'pegawai\pegawai@logout_pegawai');
Route::post('/izin_masuk/{id}/absen_id/{absen}', 'pegawai\pegawai@izin_masuk');
Route::get('/refersh/{id}', 'pegawai\pegawai@refersh')->middleware('not_login_pegawai');
Route::post('/masuk/{id}/absen_id/{absen}', 'pegawai\pegawai@masuk');
Route::get('/absen_pegawai_user/{id}/absen_id/{absen}', 'pegawai\pegawai@absen_pegawai_user')->middleware('not_login_pegawai');
Route::get('/profile_pegawai/{id}', 'pegawai\pegawai@profile_pegawai')->middleware('not_login_pegawai');
Route::get('/arsip_pegawai', 'pegawai\pegawai@arsip_pegawai')->middleware('not_login_pegawai');
Route::get('/slip_gaji_pegawai', 'pegawai\pegawai@slip_gaji_pegawai')->middleware('not_login_pegawai');
Route::post('/simpan_profile_pegawai/{id}', 'pegawai\pegawai@simpan_profile_pegawai');

// forgot password
Route::get('/forgot_password', 'LoginController@forgot_password');
Route::post('/send_email', 'LoginController@send_email');
Route::get('/rename_password/{email}', 'LoginController@rename_password');
Route::post('/send_password/{email}', 'LoginController@send_password');
Route::get('/aktifasi_akun/{email}', 'LoginController@aktifasi_akun');

// slip gaji
Route::get('/slip_gaji', 'admin\DashboardController@slip_gaji')->middleware('not_login');
Route::get('/tambah_slip_gaji', 'admin\DashboardController@tambah_slip_gaji')->middleware('not_login');
Route::get('/edit_slip_gaji/{id}', 'admin\DashboardController@edit_slip_gaji')->middleware('not_login');
Route::get('/arsip', 'admin\DashboardController@arsip')->middleware('not_login');
Route::get('/tambah_arsip', 'admin\DashboardController@tambah_arsip')->middleware('not_login');
Route::get('/edit_arsip/{id}', 'admin\DashboardController@edit_arsip')->middleware('not_login');
Route::post('/update_arsip/{id}', 'admin\DashboardController@update_arsip');
Route::post('/insert_arsip', 'admin\DashboardController@insert_arsip');
Route::post('/tambah_file_slip_gaji', 'admin\DashboardController@tambah_file_slip_gaji');
Route::post('/update_slip_gaji/{id}', 'admin\DashboardController@update_slip_gaji');
Route::delete('/hapus_slip_gaji/{id}', 'admin\DashboardController@hapus_slip_gaji');
Route::delete('/hapus_arsip/{id}', 'admin\DashboardController@hapus_arsip');
