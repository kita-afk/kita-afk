<?php

namespace App\Http\Controllers;

use App\Models\pengguna;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Redis;
use Illuminate\View\Component;

class LoginController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        date_default_timezone_set('Asia/Jayapura');
        // login
        $data = [
            'title' => 'LOGIN'
        ];
        return view('login',$data);
    }

    public function login(Request $request)
    {
        date_default_timezone_set('Asia/Jayapura');
        $username = $request->username;
        $password = $request->password;

        $request->validate([
            'username'  =>  'required|min:8|max:50',
            'password'  =>  'required|min:8|max:50'
        ]);

        $data_username = pengguna::all()->where('username',$username)->first();
        if(!$data_username) {
            return redirect('/')->with('status_user_login','Username Salah');
        }

        $data_password = password_verify($password,$data_username->pass);
        if(!$data_password) {
            return redirect('/')->with('status_user_login','Password Salah');
        }

        if($data_username->is_active == 0) {
            return redirect('/')->with('status_user_login','Akun Tidak Aktif');
        }

        if($data_username->role_id == 1) {
            session([
                'login' => true,
                'nama'  => $data_username->nama,
                'username'  =>  $data_username->username,
                'password'  =>  $data_username->pass,
                'img'   =>  $data_username->img,
                'is_active' =>  $data_username->is_active,
                'role_id'   =>  $data_username->role_id,
                'created'   =>  $data_username->created,
                'tanggal_lahir' =>  $data_username->tanggal_lahir,
                'id'    =>  $data_username->id_pengguna
            ]);
            return redirect('/dashboard');
        } else {
            session([
                'login_pegawai' => true,
                'nama'  => $data_username->nama,
                'username'  =>  $data_username->username,
                'password'  =>  $data_username->pass,
                'img'   =>  $data_username->img,
                'is_active' =>  $data_username->is_active,
                'role_id'   =>  $data_username->role_id,
                'created'   =>  $data_username->created,
                'tanggal_lahir' =>  $data_username->tanggal_lahir,
                'id'    =>  $data_username->id_pengguna
            ]);
            return redirect('/pegawai');
        }


    }

    public function registrer(Request $request)
    {
        date_default_timezone_set('Asia/Jayapura');
        $data = [
            'title' =>  'REGISTRASI'
        ];

        return view('register',$data);
    }

    public function register_user(Request $request)
    {
        date_default_timezone_set('Asia/Jayapura');
        $nama       =   $request->nama;
        $username   =   $request->username;
        $password   =   $request->password;
        $level   =   $request->level;
        $tanggal_lahir   =   $request->tanggal_lahir;
        $ulangi_password    =   $request->ulangi_password;
        $email = $request->email;
        $jabatan = $request->jabatan;
        $satuan = $request->satuan;

        $request->validate([
            'nama'  =>  'required|min:5|max:50',
            'username'  =>  'required|min:8|max:50',
            'password'  =>  'required|min:8|max:50',
            'ulangi_password'   =>  'required|min:8|max:50',
            'level' =>  'required',
            'tanggal_lahir' =>  'required',
            'email' =>  'required|min:5|max:50',
            'jabatan'   =>  'required|min:3',
            'satuan'    =>  'required'
        ]);

        $data_username = pengguna::all()->where('username',$username)->first();
        if($data_username) {
            return redirect('/register')->with('status_eror','Username Sudah Ada');
        }

        $data_email = pengguna::all()->where('email',$email)->first();
        if($data_email) {
            return redirect('/register')->with('status_eror','Email Sudah Ada');
        }

        if($password != $ulangi_password) {
            return redirect('/register')->with('status_eror','Password Tidak Sama');
        }

        $hash_password = password_hash($password,PASSWORD_DEFAULT);

        DB::table('pengguna')->insert([
            'nama'  =>  $nama,
            'username'  =>  $username,
            'pass'  =>  $hash_password,
            'img'   =>  'default.png',
            'created'   =>  now(),
            'is_active' =>  '0',
            'role_id'   =>  $level,
            'tanggal_lahir' =>  $tanggal_lahir,
            'jabatan'   =>  $jabatan,
            'email' =>  $email,
            'satuan'    =>  $satuan
        ]);

        $details = [
            'title' =>  'ABSENSI PEGAWAI',
            'body'  => "data",
            'email' =>  $email
        ];

        \Mail::to($email)->send(new \App\Mail\aktifasi($details));

        return redirect('/')->with('status_login','Berhasil Di Tambahkan Dan Cek Email Anda Untuk Aktifasi Akun');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function forgot_password(Request $request)
    {
        date_default_timezone_set('Asia/Jayapura');
        // forgot password
        $data = [
            'title' =>  'LUPA PASSWORD'
        ];

        return view('forgot-password',$data);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function send_email(Request $request)
    {
        date_default_timezone_set('Asia/Jayapura');
        // send email
        $email = $request->email;

        $request->validate([
            'email' =>  'required|min:4'
        ]);

        $data_email =  pengguna::all()->where('email',$email)->first();
        if(!$data_email) {
            return redirect('/forgot_password')->with('status_email','Email Tidak Di Temukan');
        }

        $details = [
                    'title' =>  'ABSENSI PEGAWAI',
                    'body'  => "data",
                    'email' =>  $email
                ];

        \Mail::to($email)->send(new \App\Mail\EmailController($details));

        return redirect('/')->with('status_profile_login','Email Berhasil Terkirim');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function rename_password($email)
    {
        date_default_timezone_set('Asia/Jayapura');
        // rename email
        $data = [
            'title' =>  'FORGOT PASSWORD',
            'email' =>  $email
        ];
        return view('rename_password',$data);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function send_password(Request $request,  $email)
    {
        date_default_timezone_set('Asia/Jayapura');
        // send password
        $password_baru = $request->password_baru;
        $ulangi_password = $request->ulangi_password;

        $request->validate([
            'password_baru' =>  'required|min:8|max:50',
            'ulangi_password'   =>  'required|min:8|max:50'
        ]);

        if($password_baru != $ulangi_password) {
            return redirect('/rename_password' . '/' . $email)->with('status_rename_password','Password Tidak Sama');
        }

        $password = password_hash($password_baru,PASSWORD_DEFAULT);

        DB::table('pengguna')->where('email',$email)->update([
            'pass'  =>  $password
        ]);

        return redirect('/')->with('status_login','Password Berhasil Di Reset');
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function aktifasi_akun(Request $request, $email)
    {
        date_default_timezone_set('Asia/Jayapura');
        // aktifasi email
        DB::table('pengguna')->where('email',$email)->update([
            'is_active' =>  1
        ]);

        return redirect('/')->with('status_login','Akun Berhasil Aktif');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
