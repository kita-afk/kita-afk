<?php

namespace App\Http\Controllers\pegawai;

use App\Http\Controllers\Controller;
use App\Models\absen;
use App\Models\absen_pegawai;
use App\Models\arsip;
use App\Models\pengguna;
use App\Models\slip_gaji;
use App\Models\token;
use App\Models\upload_file;
use Carbon\Carbon;
use DateTime;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon as SupportCarbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Redis;

class pegawai extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        date_default_timezone_set('Asia/Jayapura');
        $absen = absen::all();
        $num_absensi = absen::all()->count();
        $upload_file = upload_file::all();
        $pengguna = pengguna::all()->count();
        $num_arsip = arsip::all()->count();
        $id = $request->session()->get('id');
        $num_slip_gaji = slip_gaji::all()->where('pengguna_id',$id)->count();
        $num_file = DB::table('upload_file')->get()->count() + $num_arsip + $num_slip_gaji;

        //pegawai
        $data = [
            'title' =>  'PENCAIRAN',
            'nama'  =>  $request->session()->get('nama'),
            'username'  =>  $request->session()->get('username'),
            'password'  =>  $request->session()->get('password'),
            'img'   =>  $request->session()->get('img'),
            'is_active' =>  $request->session()->get('is_active'),
            'role_id'   =>  $request->session()->get('role_id'),
            'tanggal_lahir' => $request->session()->get('tanggal_lahir'),
            'created'   =>  $request->session()->get('created'),
            'id'    =>  $request->session()->get('id'),
            'login' =>  $request->session()->get('login'),
            'absen' =>  $absen,
            'file'  =>  $upload_file,
            'num_file'  =>  $num_file,
            'pengguna'  =>  $pengguna,
            'num_absensi'   =>  $num_absensi
        ];
        return view('page.pegawai.index',$data);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function absensi_user_pegawai(Request $request,$id)
    {
        date_default_timezone_set('Asia/Jayapura');
        // absensi
        $data_absen = absen_pegawai::all()->where('pengguna_id',$id)->first();
        $absen = absen::all();
        $absen_on = absen_pegawai::all();
        $num_absensi = absen::all()->count();
        $upload_file = upload_file::all();
        $pengguna = pengguna::all()->count();
        $num_file = DB::table('upload_file')->get()->count();
        $izin = absen_pegawai::all()->where('pengguna_id',$id)->count();
        $num_izin = absen_pegawai::all()->count();
        $data_absen_pegawai = absen_pegawai::all();
        $num_data_absen_pegawai = absen_pegawai::all()->count();
        $count_arsip = arsip::all()->count();
        $count_slip_gaji = slip_gaji::all()->where('pengguna_id',$id)->count();
        $num_file_all = upload_file::all()->count() + $count_slip_gaji + $count_arsip;

        if(!$izin) {
            foreach($absen as $row) {
                DB::table('absen_pegawai')->insert([
                    'pengguna_id'   =>  $id,
                    'absen' =>  '0',
                    'absen_id'  =>  $row->id_absen,
                    'waktu' =>  now(),
                    'pesan_alasan' =>  null,
                    'file_data'  =>  null
                ]);
                echo "<script>
                    document.location.reload();
                </script>";
            }
        }

        //pegawai
        $data = [
            'title' =>  'PEMBINAAN',
            'nama'  =>  $request->session()->get('nama'),
            'username'  =>  $request->session()->get('username'),
            'password'  =>  $request->session()->get('password'),
            'img'   =>  $request->session()->get('img'),
            'is_active' =>  $request->session()->get('is_active'),
            'role_id'   =>  $request->session()->get('role_id'),
            'tanggal_lahir' => $request->session()->get('tanggal_lahir'),
            'created'   =>  $request->session()->get('created'),
            'id'    =>  $request->session()->get('id'),
            'login' =>  $request->session()->get('login'),
            'absen' =>  $absen,
            'file'  =>  $upload_file,
            'num_file'  =>  $num_file,
            'pengguna'  =>  $pengguna,
            'num_absensi'   =>  $num_absensi,
            'data_absen'    =>  $data_absen,
            'izin'  =>  $izin,
            'data_absen_pegawai'    =>  $data_absen_pegawai,
            'num_data_absen_pegawai'    =>  $num_data_absen_pegawai,
            'absen_on'  =>  $absen_on,
            'num_izin'  => $num_izin,
            'num_file_all'  =>  $num_file_all
        ];
        return view('page.pegawai.absensi',$data);
    }

    public function absen_pegawai_user(Request $request,$id,$id_absen)
    {
        date_default_timezone_set('Asia/Jayapura');
        $absen = absen::all();
        $num_absensi = absen::all()->count();
        $upload_file = upload_file::all();
        $pengguna = pengguna::all()->count();
        $id_pengguna = $request->session()->get('id');
        $num_file = DB::table('upload_file')->get()->count();
        $data_pegawai_absen = DB::table('absen_pegawai')->join('absen','absen_pegawai.absen_id','=','absen.id_absen')->where('id_absensi_pegawai',$id)->first();

        $konek = mysqli_connect('localhost','root','','absensi_pegawai');
                                        $query = mysqli_query($konek,"SELECT * FROM pengguna INNER JOIN token ON pengguna.id_pengguna = token.pengguna_id WHERE pengguna_id = $id_pengguna AND absen_id = $id_absen");
        $num_rows = mysqli_fetch_assoc($query);

        $data = [
            'title' =>  'ABSEN PEGAWAI',
            'nama'  =>  $request->session()->get('nama'),
            'username'  =>  $request->session()->get('username'),
            'password'  =>  $request->session()->get('password'),
            'img'   =>  $request->session()->get('img'),
            'is_active' =>  $request->session()->get('is_active'),
            'role_id'   =>  $request->session()->get('role_id'),
            'tanggal_lahir' => $request->session()->get('tanggal_lahir'),
            'created'   =>  $request->session()->get('created'),
            'id'    =>  $request->session()->get('id'),
            'login' =>  $request->session()->get('login'),
            'absen' =>  $absen,
            'file'  =>  $upload_file,
            'num_file'  =>  $num_file,
            'pengguna'  =>  $pengguna,
            'num_absensi'   =>  $num_absensi,
            'id_absensi_pegawai'    =>  $id,
            'data_pegawai_absen'    =>  $data_pegawai_absen,
            'data_token'    =>  $num_rows,
            'id_absen'  =>  $id_absen
        ];

        return view('page.pegawai.absensi_pegawai',$data);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function izin_masuk(Request $request,$id,$absen)
    {
        date_default_timezone_set('Asia/Jayapura');
        // izin masuk
        $izin = $request->alasan;
        $pesan = $request->pesan;
        $file_baru = $request->file('file');
        $id_absensi_pegawai = $request->absen_id;
        $pengguna_id = $request->pengguna_id;
        $input_token = $request->token;

        $request->validate([
            'token' =>  'required'
        ]);

        if(!$file_baru) {
            $file = null;
        } else {
            $file = $request->file->getClientOriginalName() . '-' . time() . '.' . $request->file->extension();
            $request->file->move(public_path('asset/file'),$file);
        }

        if(!$pesan) {
            $message = null;
        } else {
            $message = $pesan;
        }

        $konek = mysqli_connect('localhost','root','','absensi_pegawai');
                                        $query = mysqli_query($konek,"SELECT * FROM pengguna INNER JOIN token ON pengguna.id_pengguna = token.pengguna_id WHERE token = '$input_token' AND absen_id = $absen AND pengguna_id = $pengguna_id");
        $num_rows = mysqli_fetch_assoc($query);
        if(!$num_rows) {
            return redirect('/absen_pegawai_user' . '/' . $id . '/absen_id' . '/' . $absen )->with('token','Token Anda Salah');
        }

        DB::table('absen_pegawai')->where('id_absensi_pegawai',$id_absensi_pegawai)->update([
            // 'pengguna_id' =>    $pengguna_id,
            'absen' =>  $izin,
            // 'absen_id'  =>  $id_absensi_pegawai,
            'waktu' =>  now(),
            'pesan_alasan' =>  $message,
            'file_data'  =>  $file
        ]);

        return redirect('/absensi_user_pegawai' . '/' . $pengguna_id)->with('status_file','Permintaan Izin Terkirim');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function refersh(Request $request, $id)
    {
        date_default_timezone_set('Asia/Jayapura');
        // refersh
        return redirect('/absensi_user_pegawai'. '/' . $id);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function masuk(Request $request, $id,$absen)
    {
        date_default_timezone_set('Asia/Jayapura');
        // masuk absen
        $pengguna_id = $request->pengguna_id;
        $absen_id = $request->absen_id;
        $input_token = $request->token;

        $request->validate([
            'token' =>  'required'
        ]);

        $konek = mysqli_connect('localhost','root','','absensi_pegawai');
                                        $query = mysqli_query($konek,"SELECT * FROM pengguna INNER JOIN token ON pengguna.id_pengguna = token.pengguna_id WHERE token = '$input_token' AND absen_id = $absen AND pengguna_id = $pengguna_id");
        $num_rows = mysqli_fetch_assoc($query);
        if(!$num_rows) {
            return redirect('/absen_pegawai_user' . '/' . $id . '/absen_id' . '/' . $absen )->with('token','Token Anda Salah');
        }

        DB::table('absen_pegawai')->where('id_absensi_pegawai',$absen_id)->update([
            'absen' =>  6,
            'waktu' =>  now()
        ]);

        return redirect('/absensi_user_pegawai' . '/' . $pengguna_id)->with('status_file','Absen');
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function profile_pegawai(Request $request, $id)
    {
        date_default_timezone_set('Asia/Jayapura');
        // profil pegawai
        $pengguna = pengguna::all()->where('id_pengguna',$id)->first();

        $data = [
            'title' =>  'PROFIL',
            'nama'  =>  $request->session()->get('nama'),
            'username'  =>  $request->session()->get('username'),
            'password'  =>  $request->session()->get('password'),
            'img'   =>  $request->session()->get('img'),
            'is_active' =>  $request->session()->get('is_active'),
            'role_id'   =>  $request->session()->get('role_id'),
            'tanggal_lahir' => $request->session()->get('tanggal_lahir'),
            'created'   =>  $request->session()->get('created'),
            'id'    =>  $request->session()->get('id'),
            'login' =>  $request->session()->get('login'),
            'pengguna'  =>  $pengguna
        ];

        return view('page.pegawai.profile',$data);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function simpan_profile_pegawai(Request $request, $id)
    {
        date_default_timezone_set('Asia/Jayapura');
        // simpan profile
        $gambar_lama = $request->gambar_lama;
        $password_lama = $request->password_lama;
        $password_baru = $request->password_baru;
        $ulangi_password = $request->ulangi_password;
        $gambar_baru = $request->file('img');

        $request->validate([
            'password_lama' =>  'required|min:8|max:12',
            'password_baru' =>  'required|min:8|max:12',
            'ulangi_password' =>  'required|min:8|max:12',
            'img'   =>  'mimes:png,jpg,jpeg'
        ]);

        $pengguna = pengguna::all()->where('id_pengguna',$id)->first();
        if(!password_verify($password_lama,$pengguna->pass)) {
            return redirect('/profile_pegawai' . '/' . $id)->with('status_profile_pegawai','Password Sudah Ada');
        }

        if($password_lama == $password_baru) {
            return redirect('/profile_pegawai' . '/' . $id)->with('status_profile_pegawai','Password Harus Beda');
        }

        if($password_baru != $ulangi_password) {
            return redirect('/profile_pegawai' . '/' . $id)->with('status_profile_pegawai','Password Tidak Sama');
        }

        if(!$gambar_baru) {
            $img = $gambar_lama;
        } else {
            $img = $request->img->getClientOriginalName() . '-' . time() . '.' . $request->img->extension();
            $request->img->move(public_path('asset/img'),$img);
        }

        $password = password_hash($password_baru,PASSWORD_DEFAULT);

        DB::table('pengguna')->where('id_pengguna',$id)->update([
            'pass'  =>  $password,
            'img'   =>  $img
        ]);

        $request->session()->forget('login_pegawai');
        return redirect('/')->with('status_profile_login','Di Update');
    }

    public function logout_pegawai(Request $request,$id)
    {
        date_default_timezone_set('Asia/Jayapura');
        $request->session()->forget('login_pegawai');
        return redirect('/');
    }

    public function slip_gaji_pegawai(Request $request)
    {
        date_default_timezone_set('Asia/Jayapura');
        $absen = absen::all();
        $num_absensi = absen::all()->count();
        $id = $request->session()->get('id');
        $upload_file = slip_gaji::all()->where('pengguna_id',$id);
        $pengguna = pengguna::all()->count();
        $num_file = slip_gaji::all()->where('pengguna_id',$id)->count();
        $count_arsip = arsip::all()->count();
        $count_slip_gaji = slip_gaji::all()->where('pengguna_id',$id)->count();
        $num_file_all = upload_file::all()->count() + $count_slip_gaji + $count_arsip;

        $data = [
            'title' =>  'SLIP GAJI',
            'nama'  =>  $request->session()->get('nama'),
            'username'  =>  $request->session()->get('username'),
            'password'  =>  $request->session()->get('password'),
            'img'   =>  $request->session()->get('img'),
            'is_active' =>  $request->session()->get('is_active'),
            'role_id'   =>  $request->session()->get('role_id'),
            'tanggal_lahir' => $request->session()->get('tanggal_lahir'),
            'created'   =>  $request->session()->get('created'),
            'id'    =>  $request->session()->get('id'),
            'login' =>  $request->session()->get('login'),
            'absen' =>  $absen,
            'file'  =>  $upload_file,
            'num_file'  =>  $num_file,
            'pengguna'  =>  $pengguna,
            'num_absensi'   =>  $num_absensi,
            'num_file_all'  => $num_file_all
        ];

        return view('page.pegawai.slip_gaji',$data);
    }

    public function arsip_pegawai(Request $request)
    {
        date_default_timezone_set('Asia/Jayapura');
        $absen = absen::all();
        $num_absensi = absen::all()->count();
        $upload_file = slip_gaji::all();
        $pengguna = pengguna::all()->count();
        $num_file = slip_gaji::all()->count();
        $arsip = arsip::all();
        $num_arsip = arsip::all()->count();
        $count_arsip = arsip::all()->count();
        $id = $request->session()->get('id');
        $count_slip_gaji = slip_gaji::all()->where('pengguna_id',$id)->count();
        $num_file_all = upload_file::all()->count() + $count_slip_gaji + $count_arsip;

        $data = [
            'title' =>  'ARSIP',
            'nama'  =>  $request->session()->get('nama'),
            'username'  =>  $request->session()->get('username'),
            'password'  =>  $request->session()->get('password'),
            'img'   =>  $request->session()->get('img'),
            'is_active' =>  $request->session()->get('is_active'),
            'role_id'   =>  $request->session()->get('role_id'),
            'tanggal_lahir' => $request->session()->get('tanggal_lahir'),
            'created'   =>  $request->session()->get('created'),
            'id'    =>  $request->session()->get('id'),
            'login' =>  $request->session()->get('login'),
            'absen' =>  $absen,
            'file'  =>  $upload_file,
            'num_file'  =>  $num_file,
            'pengguna'  =>  $pengguna,
            'num_absensi'   =>  $num_absensi,
            'num_arsip' =>  $num_arsip,
            'arsip' =>  $arsip,
            'num_file_all'  => $num_file_all
        ];

        return view('page.pegawai.arsip_pegawai',$data);
    }
}
