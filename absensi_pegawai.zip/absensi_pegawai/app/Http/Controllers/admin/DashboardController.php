<?php

namespace App\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use App\Models\absen;
use App\Models\absen_pegawai;
use App\Models\arsip;
use App\Models\pengguna;
use App\Models\slip_gaji;
use App\Models\token;
use App\Models\upload_file;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Redis;
use Illuminate\Support\Str;

class DashboardController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        date_default_timezone_set('Asia/Jayapura');
        // dashboard
        $absen = absen::all();
        $num_absensi = absen::all()->count();
        $upload_file = upload_file::all();
        $pengguna = pengguna::all()->count();
        $num_arsip = arsip::all()->count();
        $slip_gaji_num =    slip_gaji::all()->count();
        $num_file = DB::table('upload_file')->get()->count() + $num_arsip + $slip_gaji_num;

        $data = [
            'title' =>  'PENCAIRAN',
            'nama'  =>  $request->session()->get('nama'),
            'username'  =>  $request->session()->get('username'),
            'password'  =>  $request->session()->get('password'),
            'img'   =>  $request->session()->get('img'),
            'is_active' =>  $request->session()->get('is_active'),
            'role_id'   =>  $request->session()->get('role_id'),
            'tanggal_lahir' => $request->session()->get('tanggal_lahir'),
            'created'   =>  $request->session()->get('created'),
            'id'    =>  $request->session()->get('id'),
            'login' =>  $request->session()->get('login'),
            'absen' =>  $absen,
            'file'  =>  $upload_file,
            'num_file'  =>  $num_file,
            'pengguna'  =>  $pengguna,
            'num_absensi'   =>  $num_absensi
        ];
        return view('page.admin.index',$data);
    }

    public function tambah_file(Request $request)
    {
        date_default_timezone_set('Asia/Jayapura');
        $data = [
            'title' => 'TAMBAH PENCAIRAN',
            'nama'  =>  $request->session()->get('nama'),
            'username'  =>  $request->session()->get('username'),
            'password'  =>  $request->session()->get('password'),
            'img'   =>  $request->session()->get('img'),
            'is_active' =>  $request->session()->get('is_active'),
            'role_id'   =>  $request->session()->get('role_id'),
            'tanggal_lahir' => $request->session()->get('tanggal_lahir'),
            'created'   =>  $request->session()->get('created'),
            'id'    =>  $request->session()->get('id'),
            'login' =>  $request->session()->get('login')
        ];
        return view('page.admin.upload_file.tambah_file',$data);
    }

    public function tambah_upload_file(Request $request)
    {
        date_default_timezone_set('Asia/Jayapura');
        $id = $request->id;
        $pesan = $request->pesan;
        $request->validate([
            'file'  =>  'required|mimes:pdf',
            'pesan' =>  'required|min:50'
        ]);

        // upload gambar
        $file = $request->file->getClientOriginalName() . '-' . time() . '.' . $request->file->extension();
        $request->file->move(public_path('asset/file'),$file);

        DB::table('upload_file')->insert([
            'file'  => $file,
            'pengguna_id'   =>  $id,
            'status_file'   =>  1,
            'keterangan'    =>  $pesan,
            'waktu_file'    =>  now()
        ]);

        return redirect('/dashboard')->with('status_file','Di Tambahkan');
    }

    public function edit_file(Request $request,$id)
    {
        date_default_timezone_set('Asia/Jayapura');
        $file = upload_file::all()->where('id_upload_file',$id)->first();
        $data = [
            'title' =>  'EDIT PENCAIRAN',
            'nama'  =>  $request->session()->get('nama'),
            'username'  =>  $request->session()->get('username'),
            'password'  =>  $request->session()->get('password'),
            'img'   =>  $request->session()->get('img'),
            'is_active' =>  $request->session()->get('is_active'),
            'role_id'   =>  $request->session()->get('role_id'),
            'tanggal_lahir' => $request->session()->get('tanggal_lahir'),
            'created'   =>  $request->session()->get('created'),
            'id'    =>  $request->session()->get('id'),
            'login' =>  $request->session()->get('login'),
            'file'  =>  $file
        ];

        return view('page.admin.upload_file.edit_file',$data);
    }

    public function edit_upload_file(Request $request,$id)
    {
        date_default_timezone_set('Asia/Jayapura');
        $pengguna_id = $request->id;
        $file_lama = $request->file_lama;
        $file_baru = $request->file('file');
        $pesan = $request->pesan;

        $request->validate([
            'file'  =>  'mimes:pdf',
            'pesan' =>  'required|min:50'
        ]);

        if(!$file_baru) {
            $file = $file_lama;
        } else {
            // upload gambar
            $file = $request->file->getClientOriginalName() . '-' . time() . '.' . $request->file->extension();
            $request->file->move(public_path('asset/file'),$file);
        }

        DB::table('upload_file')->where('id_upload_file',$id)->update([
            'file'  =>  $file,
            'pengguna_id'   =>  $pengguna_id,
            'status_file'   =>  2,
            'keterangan'    =>  $pesan,
            'waktu_file'    =>  now()
        ]);

        return redirect('/dashboard')->with('status_file','Di Update');
    }


    public function hapus_file(Request $request,$id)
    {
        date_default_timezone_set('Asia/Jayapura');
        upload_file::destroy($id);
        return redirect('/dashboard')->with('status_file','Di Hapus');
    }

    public function proses_file(Request $request,$id)
    {
        date_default_timezone_set('Asia/Jayapura');
        DB::table('upload_file')->where('id_upload_file',$id)->update([
            'status_file'    =>  3,
            'waktu_file'    =>  now()
        ]);

        return redirect('/dashboard')->with('status_file','Sedang Di Proses');
    }

    public function approved(Request $request,$id)
    {
        date_default_timezone_set('Asia/Jayapura');
        DB::table('upload_file')->where('id_upload_file',$id)->update([
            'status_file'   =>  4,
            'waktu_file'    =>  now()
        ]);

        return redirect('/dashboard')->with('status_file','Dana Sudah Cair');
    }

    public function absensi(Request $request)
    {
        date_default_timezone_set('Asia/Jayapura');
        $absen = absen::all();
        $num_absensi = absen::all()->count();
        $upload_file = upload_file::all();
        $pengguna = pengguna::all()->count();
        $num_arsip = arsip::all()->count();
        $num_slip_gaji = slip_gaji::all()->count();
        $num_file = DB::table('upload_file')->get()->count() + $num_arsip + $num_slip_gaji;

        $data = [
            'title' =>  'ABSENSI',
            'nama'  =>  $request->session()->get('nama'),
            'username'  =>  $request->session()->get('username'),
            'password'  =>  $request->session()->get('password'),
            'img'   =>  $request->session()->get('img'),
            'is_active' =>  $request->session()->get('is_active'),
            'role_id'   =>  $request->session()->get('role_id'),
            'tanggal_lahir' => $request->session()->get('tanggal_lahir'),
            'created'   =>  $request->session()->get('created'),
            'id'    =>  $request->session()->get('id'),
            'login' =>  $request->session()->get('login'),
            'absen' =>  $absen,
            'file'  =>  $upload_file,
            'num_file'  =>  $num_file,
            'pengguna'  =>  $pengguna,
            'num_absensi'   =>  $num_absensi
        ];

        return view('page.admin.absensi',$data);
    }

    public function tambah_absen(Request $request)
    {
        date_default_timezone_set('Asia/Jayapura');
        $absen = absen::all();
        $data = [
            'title' =>  'TAMBAH ABSEN',
            'nama'  =>  $request->session()->get('nama'),
            'username'  =>  $request->session()->get('username'),
            'password'  =>  $request->session()->get('password'),
            'img'   =>  $request->session()->get('img'),
            'is_active' =>  $request->session()->get('is_active'),
            'role_id'   =>  $request->session()->get('role_id'),
            'tanggal_lahir' => $request->session()->get('tanggal_lahir'),
            'created'   =>  $request->session()->get('created'),
            'id'    =>  $request->session()->get('id'),
            'login' =>  $request->session()->get('login'),
            'absen' =>  $absen
        ];

        return view('page.admin.absen.tambah_absen',$data);
    }

    public function tambah_absensi_pegawai(Request $request)
    {
        date_default_timezone_set('Asia/Jayapura');
        $pengguna_id =$request->id;
        $judul = $request->judul;
        $pesan = $request->pesan;
        $waktu_mulai = $request->waktu_mulai;
        $waktu_akhir    =$request->waktu_akhir;

        $request->validate([
            'judul' =>  'required|min:10',
            'pesan' =>  'required|min:50',
            'waktu_mulai'   =>   'required',
            'waktu_akhir'   =>   'required'
        ]);

        DB::table('absen')->insert([
            'judul' =>  $judul,
            'pesan' =>  $pesan,
            'waktu_mulai'   =>  $waktu_mulai,
            'waktu_akhir'   =>  $waktu_akhir,
            'absensi_pengguna'   =>  $pengguna_id
        ]);

        return redirect('/absensi')->with('status_file','Di Tambahkan');
    }

    public function edit_absen(Request $request,$id)
    {
        date_default_timezone_set('Asia/Jayapura');
        $absen = absen::all()->where('id_absen',$id)->first();
        $data = [
            'title' =>  'EDIT ABSEN',
            'nama'  =>  $request->session()->get('nama'),
            'username'  =>  $request->session()->get('username'),
            'password'  =>  $request->session()->get('password'),
            'img'   =>  $request->session()->get('img'),
            'is_active' =>  $request->session()->get('is_active'),
            'role_id'   =>  $request->session()->get('role_id'),
            'tanggal_lahir' => $request->session()->get('tanggal_lahir'),
            'created'   =>  $request->session()->get('created'),
            'id'    =>  $request->session()->get('id'),
            'login' =>  $request->session()->get('login'),
            'absen' =>  $absen
        ];

        return view('page.admin.absen.edit_absensi',$data);
    }
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function edit_absensi_pegawai(Request $request,$id)
    {
        date_default_timezone_set('Asia/Jayapura');
        // edit absen
        $pengguna_id =$request->id;
        $judul = $request->judul;
        $pesan = $request->pesan;
        $waktu_mulai = $request->waktu_mulai;
        $waktu_akhir    =$request->waktu_akhir;

        $request->validate([
            'judul' =>  'required|min:10',
            'pesan' =>  'required|min:50',
            'waktu_mulai'   =>   'required',
            'waktu_akhir'   =>   'required'
        ]);

        DB::table('absen')->where('id_absen',$id)->update([
            'judul' =>  $judul,
            'pesan' =>  $pesan,
            'waktu_mulai'   =>  $waktu_mulai,
            'waktu_akhir'   =>  $waktu_akhir,
            'absensi_pengguna'   =>  $pengguna_id
        ]);

        return redirect('/absensi')->with('status_file','Di Update');
    }

    public function hapus_absen_pegawai(Request $request,$id)
    {
        date_default_timezone_set('Asia/Jayapura');
        absen::destroy($id);
        return redirect('/absensi')->with('status_file','Di Hapus');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function absensi_pegawai(Request $request,$id)
    {
        date_default_timezone_set('Asia/Jayapura');
        // absen pegawai
        $absen = absen::all()->where('id_absen',$id)->first();
        $absen_pegawai = DB::table('pengguna')->join('absen_pegawai','pengguna.id_pengguna','=','absen_pegawai.pengguna_id')->where('absen_id',$id)->get();
        $pengguna = pengguna::all();
        $num_pengguna = pengguna::all()->count();
        $num_absensi = absen::all()->count();
        $upload_file = upload_file::all();
        $num_file = DB::table('upload_file')->get()->count();
        $data_absen_pegawai = DB::table('absen')->leftJoin('absen_pegawai','absen.id_absen','=','absen_pegawai.absen_id')->select('absen.*')->where('id_absen',$id)->first();
        $num_absen_pegawai = absen_pegawai::all()->where('absen_id',$id)->count();

        $data = [
            'title' =>  'ABSENSI PEGAWAI',
            'nama'  =>  $request->session()->get('nama'),
            'username'  =>  $request->session()->get('username'),
            'password'  =>  $request->session()->get('password'),
            'img'   =>  $request->session()->get('img'),
            'is_active' =>  $request->session()->get('is_active'),
            'role_id'   =>  $request->session()->get('role_id'),
            'tanggal_lahir' => $request->session()->get('tanggal_lahir'),
            'created'   =>  $request->session()->get('created'),
            'id'    =>  $request->session()->get('id'),
            'login' =>  $request->session()->get('login'),
            'absen' =>  $absen,
            'absen_pegawai' =>  $absen_pegawai,
            'pengguna' =>  $pengguna,
            'num_pengguna'  =>  $num_pengguna,
            'file'  =>  $upload_file,
            'num_file'  =>  $num_file,
            'num_absensi'   =>  $num_absensi,
            'data_absen_pegawai' => $data_absen_pegawai,
            'num_absen_pegawai' =>  $num_absen_pegawai
        ];

        return view('page.admin.absen.absensi_pegawai',$data);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function akun(Request $request)
    {
        date_default_timezone_set('Asia/Jayapura');
        $pengguna = pengguna::all();
        $num_pengguna = pengguna::all()->count();
        $num_absensi = absen::all()->count();
        $upload_file = upload_file::all();
        $num_arsip = arsip::all()->count();
        $num_slip_gaji = slip_gaji::all()->count();
        $num_file = DB::table('upload_file')->get()->count() + $num_arsip + $num_slip_gaji;
        // akun
        $data = [
            'title' =>  'ABSENSI PEGAWAI',
            'nama'  =>  $request->session()->get('nama'),
            'username'  =>  $request->session()->get('username'),
            'password'  =>  $request->session()->get('password'),
            'img'   =>  $request->session()->get('img'),
            'is_active' =>  $request->session()->get('is_active'),
            'role_id'   =>  $request->session()->get('role_id'),
            'tanggal_lahir' => $request->session()->get('tanggal_lahir'),
            'created'   =>  $request->session()->get('created'),
            'id'    =>  $request->session()->get('id'),
            'login' =>  $request->session()->get('login'),
            'pengguna' =>  $pengguna,
            'num_pengguna'  =>  $num_pengguna,
            'file'  =>  $upload_file,
            'num_file'  =>  $num_file,
            'num_absensi'   =>  $num_absensi
        ];

        return view('page.admin.akun',$data);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function logout(Request $request, $id)
    {
        date_default_timezone_set('Asia/Jayapura');
        // logout
        $request->session()->forget('login');
        return redirect('/');
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function profile_user(Request $request, $id)
    {
        date_default_timezone_set('Asia/Jayapura');
        // profile user
        $pengguna = pengguna::all()->where('id_pengguna',$id)->first();
        $data = [
            'title' =>  'PROFILE',
            'nama'  =>  $request->session()->get('nama'),
            'username'  =>  $request->session()->get('username'),
            'password'  =>  $request->session()->get('password'),
            'img'   =>  $request->session()->get('img'),
            'is_active' =>  $request->session()->get('is_active'),
            'role_id'   =>  $request->session()->get('role_id'),
            'tanggal_lahir' => $request->session()->get('tanggal_lahir'),
            'created'   =>  $request->session()->get('created'),
            'id'    =>  $request->session()->get('id'),
            'login' =>  $request->session()->get('login'),
            'pengguna'  =>  $pengguna
        ];
        return view('page.admin.profile',$data);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function simpan_profile(Request $request, $id)
    {
        date_default_timezone_set('Asia/Jayapura');
        // simpan profile
        $password_lama = $request->password_lama;
        $password_baru = $request->password_baru;
        $ulangi_password = $request->ulangi_password;
        $gambar_lama = $request->gambar_lama;
        $gambar_baru = $request->file('img');

        $request->validate([
            'password_lama' =>  'required|min:8|max:50',
            'password_baru' =>  'required|min:8|max:50',
            'ulangi_password'   =>  'required|min:8|max:50',
            // 'img'   =>  'mimes:png,jpg,jpeg'
        ]);

        if(!$gambar_baru) {
            $img = $gambar_lama;
        } else {
            // upload gambar
            $img = $request->img->getClientOriginalName() . '-' . time() . '.' . $request->img->extension();
            $request->img->move(public_path('asset/img'),$img);
        }

        if($password_baru != $ulangi_password ) {
            return redirect('/profile' . '/' . $id)->with('status_profile','Password Tidak Sama');
        }

        if($password_lama == $password_baru ) {
            return redirect('/profile' . '/' . $id)->with('status_profile','Password Sudah ada');
        }

        $database = pengguna::all()->where('id_pengguna',$id)->first();
        if(!password_verify($password_lama,$database->pass)) {
            return redirect('/profile'. '/' . $id)->with('status_profile','Password Lama Salah');
        }

        $password = password_hash($password_baru,PASSWORD_DEFAULT);

        DB::table('pengguna')->where('id_pengguna',$id)->update([
            'pass'  =>  $password,
            'img'   =>  $img
        ]);

        $request->session()->forget('login');

        return redirect('/')->with('status_profile_admin','Di Update');
    }

    public function slip_gaji(Request $request)
    {
        date_default_timezone_set('Asia/Jayapura');
        $pengguna = pengguna::all()->count();
        $num_pengguna = pengguna::all()->count();
        $num_absensi = absen::all()->count();
        $upload_file = upload_file::all();
        $num_arsip = arsip::all()->count();
        $num_slip_gaji = slip_gaji::all()->count();
        $num_file = DB::table('upload_file')->get()->count() + $num_arsip + $num_slip_gaji;
        $slip_gaji  =   DB::table('slip_gaji')->join('pengguna','slip_gaji.pengguna_id','=','pengguna.id_pengguna')->get();
        $num_slip_gaji  =   slip_gaji::all()->count();

        $data = [
            'title' =>  'SLIP GAJI',
            'nama'  =>  $request->session()->get('nama'),
            'username'  =>  $request->session()->get('username'),
            'password'  =>  $request->session()->get('password'),
            'img'   =>  $request->session()->get('img'),
            'is_active' =>  $request->session()->get('is_active'),
            'role_id'   =>  $request->session()->get('role_id'),
            'tanggal_lahir' => $request->session()->get('tanggal_lahir'),
            'created'   =>  $request->session()->get('created'),
            'id'    =>  $request->session()->get('id'),
            'login' =>  $request->session()->get('login'),
            'pengguna'  =>  $pengguna,
            'pengguna' =>  $pengguna,
            'num_pengguna'  =>  $num_pengguna,
            'file'  =>  $upload_file,
            'num_file'  =>  $num_file,
            'num_absensi'   =>  $num_absensi,
            'slip_gaji' =>  $slip_gaji,
            'num_slip_gaji' =>  $num_slip_gaji
        ];
        return view('page.admin.slip_gaji',$data);
    }

    public function tambah_slip_gaji(Request $request)
    {
        date_default_timezone_set('Asia/Jayapura');
        $pengguna = pengguna::all()->count();
        $num_pengguna = pengguna::all()->count();
        $num_absensi = absen::all()->count();
        $upload_file = upload_file::all();
        $num_file = DB::table('upload_file')->get()->count();
        $slip_gaji  =   slip_gaji::all();
        $num_slip_gaji  =   slip_gaji::all()->count();
        $pegawai = pengguna::all()->where('role_id',2);
        $num_pegawai = pengguna::all()->where('role_id','2');

        $data = [
            'title' =>  'TAMBAH SLIP GAJI',
            'nama'  =>  $request->session()->get('nama'),
            'username'  =>  $request->session()->get('username'),
            'password'  =>  $request->session()->get('password'),
            'img'   =>  $request->session()->get('img'),
            'is_active' =>  $request->session()->get('is_active'),
            'role_id'   =>  $request->session()->get('role_id'),
            'tanggal_lahir' => $request->session()->get('tanggal_lahir'),
            'created'   =>  $request->session()->get('created'),
            'id'    =>  $request->session()->get('id'),
            'login' =>  $request->session()->get('login'),
            'pengguna'  =>  $pengguna,
            'pengguna' =>  $pengguna,
            'num_pengguna'  =>  $num_pengguna,
            'file'  =>  $upload_file,
            'num_file'  =>  $num_file,
            'num_absensi'   =>  $num_absensi,
            'slip_gaji' =>  $slip_gaji,
            'num_slip_gaji' =>  $num_slip_gaji,
            'pegawai'   =>  $pegawai,
            'num_pegawai'   =>  $num_pegawai
        ];
        return view('page.admin.upload_file.tambah_slip_gaji',$data);
    }

    public function edit_slip_gaji(Request $request,$id)
    {
        date_default_timezone_set('Asia/Jayapura');
        $pengguna = pengguna::all()->count();
        $num_pengguna = pengguna::all()->count();
        $num_absensi = absen::all()->count();
        $upload_file = upload_file::all();
        $num_file = DB::table('upload_file')->get()->count();
        $slip_gaji  =   slip_gaji::all();
        $pegawai = pengguna::all()->where('role_id',2);
        $num_slip_gaji  =   slip_gaji::all()->count();
        $data_slip   =   slip_gaji::all()->where('id_slip_gaji',$id)->first();
        $num_pegawai = pengguna::all()->where('role_id',2);

        $data = [
            'title' =>  'EDIT SLIP GAJI',
            'nama'  =>  $request->session()->get('nama'),
            'username'  =>  $request->session()->get('username'),
            'password'  =>  $request->session()->get('password'),
            'img'   =>  $request->session()->get('img'),
            'is_active' =>  $request->session()->get('is_active'),
            'role_id'   =>  $request->session()->get('role_id'),
            'tanggal_lahir' => $request->session()->get('tanggal_lahir'),
            'created'   =>  $request->session()->get('created'),
            'id'    =>  $request->session()->get('id'),
            'login' =>  $request->session()->get('login'),
            'pengguna'  =>  $pengguna,
            'pengguna' =>  $pengguna,
            'num_pengguna'  =>  $num_pengguna,
            'file'  =>  $upload_file,
            'num_file'  =>  $num_file,
            'num_absensi'   =>  $num_absensi,
            'slip_gaji' =>  $slip_gaji,
            'num_slip_gaji' =>  $num_slip_gaji,
            'data_slip'  =>  $data_slip,
            'pegawai'   =>  $pegawai,
            'num_pegawai'   =>  $num_pegawai
        ];
        return view('page.admin.upload_file.edit_slip_gaji',$data);
    }

    public function tambah_file_slip_gaji(Request $request)
    {
        date_default_timezone_set('Asia/Jayapura');
        $pesan = $request->pesan;
        $pegawai = $request->pegawai;

        $request->validate([
            'file'    =>  'required|mimes:pdf',
            'pesan'   =>  'required|min:50',
            'pegawai'   =>  'required'
        ]);

        $file = $request->file->getClientOriginalName() . '-' . time() . '.' . $request->file->extension();
        $request->file->move(public_path('asset/file'),$file);

        DB::table('slip_gaji')->insert([
            'file_slip_gaji'    =>  $file,
            'waktu_slip_gaji'   =>  now(),
            'pesan_slip_gaji'   =>  $pesan,
            'pengguna_id'   =>  $pegawai
        ]);

        return redirect('/slip_gaji')->with('status_slip_gaji','Di Tambah');
    }

    public function insert_arsip(Request $request)
    {
        date_default_timezone_set('Asia/Jayapura');
        $pesan = $request->pesan;

        $request->validate([
            'file'    =>  'required|mimes:pdf',
            'pesan'   =>  'required|min:100',
        ]);

        $file = $request->file->getClientOriginalName() . '-' . time() . '.' . $request->file->extension();
        $request->file->move(public_path('asset/file'),$file);

        DB::table('arsip')->insert([
            'file_arsip'    =>  $file,
            'waktu_arsip'   =>  now(),
            'pesan_arsip'   =>  $pesan
        ]);

        return redirect('/arsip')->with('status_arsip','Di Tambah');
    }

    public function update_slip_gaji(Request $request,$id)
    {
        date_default_timezone_set('Asia/Jayapura');
        $pesan = $request->pesan;
        $id_gaji = $request->id_gaji;
        $file_baru = $request->file('file');
        $file_lama = $request->file_lama;
        $pegawai = $request->pegawai;

        $request->validate([
            'file'    =>  'mimes:pdf',
            'pesan'   =>  'min:50',
            'pegawai'   =>  'required'
        ]);

        if(!$file_baru) {
            $file = $file_lama;
        } else {
            $file = $request->file->getClientOriginalName() . '-' . time() . '.' . $request->file->extension();
            $request->file->move(public_path('asset/file'),$file);
        }

        DB::table('slip_gaji')->where('id_slip_gaji',$id_gaji)->update([
            'file_slip_gaji'    =>  $file,
            'waktu_slip_gaji'   =>  now(),
            'pesan_slip_gaji'   =>  $pesan,
            'pengguna_id'   =>  $pegawai
        ]);

        return redirect('/slip_gaji')->with('status_slip_gaji','Di Update');
    }

    public function update_arsip(Request $request,$id)
    {
        date_default_timezone_set('Asia/Jayapura');
        $pesan = $request->pesan;
        $id_arsip = $request->id_arsip;
        $file_baru = $request->file('file');
        $file_lama = $request->file_lama;

        $request->validate([
            'file'    =>  'mimes:pdf',
            'pesan'   =>  'min:50'
        ]);

        if(!$file_baru) {
            $file = $file_lama;
        } else {
            $file = $request->file->getClientOriginalName() . '-' . time() . '.' . $request->file->extension();
            $request->file->move(public_path('asset/file'),$file);
        }

        DB::table('arsip')->where('id_arsip',$id_arsip)->update([
            'file_arsip'    =>  $file,
            'waktu_arsip'   =>  now(),
            'pesan_arsip'   =>  $pesan
        ]);

        return redirect('/arsip')->with('status_arsip','Di Update');
    }

    public function hapus_slip_gaji(Request $request,$id)
    {
        date_default_timezone_set('Asia/Jayapura');
        slip_gaji::destroy($id);
        return redirect('/slip_gaji')->with('status_slip_gaji','Di Hapus');
    }

    public function hapus_arsip(Request $request,$id)
    {
        date_default_timezone_set('Asia/Jayapura');
        arsip::destroy($id);
        return redirect('/arsip')->with('status_arsip','Di Hapus');
    }

    public function arsip(Request $request)
    {
        date_default_timezone_set('Asia/Jayapura');
        $pengguna = pengguna::all()->count();
        $num_pengguna = pengguna::all()->count();
        $num_absensi = absen::all()->count();
        $upload_file = upload_file::all();
        $count_slip_gaji = slip_gaji::all()->count();
        $count_arsip = arsip::all()->count();
        $num_file = DB::table('upload_file')->get()->count() + $count_arsip + $count_slip_gaji;
        $slip_gaji  =   slip_gaji::all();
        $num_slip_gaji  =   slip_gaji::all()->count();
        $arsip = arsip::all();
        $num_arsip = arsip::all()->count();

        $data = [
            'title' =>  'ARSIP',
            'nama'  =>  $request->session()->get('nama'),
            'username'  =>  $request->session()->get('username'),
            'password'  =>  $request->session()->get('password'),
            'img'   =>  $request->session()->get('img'),
            'is_active' =>  $request->session()->get('is_active'),
            'role_id'   =>  $request->session()->get('role_id'),
            'tanggal_lahir' => $request->session()->get('tanggal_lahir'),
            'created'   =>  $request->session()->get('created'),
            'id'    =>  $request->session()->get('id'),
            'login' =>  $request->session()->get('login'),
            'pengguna'  =>  $pengguna,
            'pengguna' =>  $pengguna,
            'num_pengguna'  =>  $num_pengguna,
            'file'  =>  $upload_file,
            'num_file'  =>  $num_file,
            'num_absensi'   =>  $num_absensi,
            'slip_gaji' =>  $slip_gaji,
            'num_slip_gaji' =>  $num_slip_gaji,
            'arsip' =>  $arsip,
            'num_arsip' =>  $num_arsip
        ];
        return view('page.admin.arsip',$data);
    }

    public function tambah_arsip(Request $request)
    {
        date_default_timezone_set('Asia/Jayapura');
        $pengguna = pengguna::all()->count();
        $num_pengguna = pengguna::all()->count();
        $num_absensi = absen::all()->count();
        $upload_file = upload_file::all();
        $num_file = DB::table('upload_file')->get()->count();
        $slip_gaji  =   slip_gaji::all();
        $num_slip_gaji  =   slip_gaji::all()->count();
        $arsip = arsip::all();
        $num_arsip = arsip::all()->count();

        $data = [
            'title' =>  'TAMBAH ARSIP',
            'nama'  =>  $request->session()->get('nama'),
            'username'  =>  $request->session()->get('username'),
            'password'  =>  $request->session()->get('password'),
            'img'   =>  $request->session()->get('img'),
            'is_active' =>  $request->session()->get('is_active'),
            'role_id'   =>  $request->session()->get('role_id'),
            'tanggal_lahir' => $request->session()->get('tanggal_lahir'),
            'created'   =>  $request->session()->get('created'),
            'id'    =>  $request->session()->get('id'),
            'login' =>  $request->session()->get('login'),
            'pengguna'  =>  $pengguna,
            'pengguna' =>  $pengguna,
            'num_pengguna'  =>  $num_pengguna,
            'file'  =>  $upload_file,
            'num_file'  =>  $num_file,
            'num_absensi'   =>  $num_absensi,
            'slip_gaji' =>  $slip_gaji,
            'num_slip_gaji' =>  $num_slip_gaji,
            'arsip' =>  $arsip,
            'num_arsip' =>  $num_arsip
        ];
        return view('page.admin.upload_file.tambah_arsip',$data);
    }

    public function edit_arsip(Request $request,$id)
    {
        date_default_timezone_set('Asia/Jayapura');
        $pengguna = pengguna::all()->count();
        $num_pengguna = pengguna::all()->count();
        $num_absensi = absen::all()->count();
        $upload_file = upload_file::all();
        $num_file = DB::table('upload_file')->get()->count();
        $slip_gaji  =   slip_gaji::all();
        $num_slip_gaji  =   slip_gaji::all()->count();
        $arsip = arsip::all()->where('id_arsip',$id)->first();
        $num_arsip = arsip::all()->count();

        $data = [
            'title' =>  'EDIT ARSIP',
            'nama'  =>  $request->session()->get('nama'),
            'username'  =>  $request->session()->get('username'),
            'password'  =>  $request->session()->get('password'),
            'img'   =>  $request->session()->get('img'),
            'is_active' =>  $request->session()->get('is_active'),
            'role_id'   =>  $request->session()->get('role_id'),
            'tanggal_lahir' => $request->session()->get('tanggal_lahir'),
            'created'   =>  $request->session()->get('created'),
            'id'    =>  $request->session()->get('id'),
            'login' =>  $request->session()->get('login'),
            'pengguna'  =>  $pengguna,
            'pengguna' =>  $pengguna,
            'num_pengguna'  =>  $num_pengguna,
            'file'  =>  $upload_file,
            'num_file'  =>  $num_file,
            'num_absensi'   =>  $num_absensi,
            'slip_gaji' =>  $slip_gaji,
            'num_slip_gaji' =>  $num_slip_gaji,
            'arsip' =>  $arsip,
            'num_arsip' =>  $num_arsip
        ];
        return view('page.admin.upload_file.edit_arsip',$data);
    }

    public function token(Request $request,$id)
    {
        date_default_timezone_set('Asia/Jayapura');
        $konek_db = mysqli_connect('localhost','root','','absensi_pegawai');
        $pegawai = pengguna::all()->where('role_id',2);
        $count_pegawai_user = pengguna::all()->where('role_id',2)->count();

        if(!$count_pegawai_user) {
            return redirect('/absen_pegawai' . '/' . $id)->with('status_token','Pegawai Belum Ada');
        }

        $query = mysqli_query($konek_db,"SELECT * FROM pengguna
                INNER JOIN token ON pengguna.id_pengguna = token.pengguna_id
                WHERE absen_id = $id AND role_id = 2");
        $num = mysqli_num_rows($query);

        if(!$num) {
            foreach($pegawai as $row) {
                $token = base64_encode(stripslashes(random_bytes(3)));
                DB::table('token')->insert([
                    'token' =>  $token,
                    'pengguna_id'   =>  $row->id_pengguna,
                    'absen_id'  =>  $id
                ]);
            }
            echo "<script>
                document.location.reload();
            </script>";
        }

        foreach($pegawai as $rows) {
            $pengguna_absen = $rows->id_pengguna;
            $data_user = mysqli_query($konek_db,"SELECT * FROM token WHERE absen_id = $id AND pengguna_id = $pengguna_absen");
            $num_user = mysqli_num_rows($data_user);
            if(!$num_user) {
                $token = base64_encode(stripslashes(random_bytes(3)));
                DB::table('token')->insert([
                    'token' =>  $token,
                    'pengguna_id'   =>  $pengguna_absen,
                    'absen_id'  =>  $id
                ]);
                echo "<script>
                    document.location.reload();
                    </script>";
            }
        }

        $pengguna = pengguna::all()->count();
        $num_pengguna = pengguna::all()->count();
        $num_absensi = absen::all()->count();
        $upload_file = upload_file::all();
        $num_file = DB::table('upload_file')->get()->count();
        $slip_gaji  =   slip_gaji::all();
        $data_absen_pegawai = DB::table('absen')->leftJoin('absen_pegawai','absen.id_absen','=','absen_pegawai.absen_id')->select('absen.*')->where('id_absen',$id)->first();
        $absen_id_user = $id;
        $num_slip_gaji  =   slip_gaji::all()->count();
        $arsip = arsip::all()->where('id_arsip',$id)->first();
        $num_arsip = arsip::all()->count();
        $token_user = DB::table('pengguna')->join('token','pengguna.id_pengguna','=','token.pengguna_id')->where('absen_id',$id)->get();
        $num_token_user = token::all()->where('absen_id',$id)->count();

        $data = [
            'title' =>  'TOKEN',
            'nama'  =>  $request->session()->get('nama'),
            'username'  =>  $request->session()->get('username'),
            'password'  =>  $request->session()->get('password'),
            'img'   =>  $request->session()->get('img'),
            'is_active' =>  $request->session()->get('is_active'),
            'role_id'   =>  $request->session()->get('role_id'),
            'tanggal_lahir' => $request->session()->get('tanggal_lahir'),
            'created'   =>  $request->session()->get('created'),
            'id'    =>  $request->session()->get('id'),
            'login' =>  $request->session()->get('login'),
            'pengguna'  =>  $pengguna,
            'pengguna' =>  $pengguna,
            'num_pengguna'  =>  $num_pengguna,
            'file'  =>  $upload_file,
            'num_file'  =>  $num_file,
            'num_absensi'   =>  $num_absensi,
            'slip_gaji' =>  $slip_gaji,
            'num_slip_gaji' =>  $num_slip_gaji,
            'arsip' =>  $arsip,
            'data_absen_pegawai'    =>  $data_absen_pegawai,
            'num_arsip' =>  $num_arsip,
            'token_user' =>  $token_user,
            'num_token_user'    =>  $num_token_user,
            'absen_id_user' =>  $absen_id_user
        ];
        return view('page.admin.token',$data);
    }
}
