<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class slip_gaji extends Model
{
    use HasFactory;
    protected $table = 'slip_gaji';
    protected $primaryKey = 'id_slip_gaji';
    public $timestamps = false;
}
