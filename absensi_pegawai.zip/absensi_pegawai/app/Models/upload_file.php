<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class upload_file extends Model
{
    use HasFactory;
    protected $table = 'upload_file';
    protected $primaryKey = 'id_upload_file';
    public $timestamps = false;
}
