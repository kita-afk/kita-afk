<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class absen_pegawai extends Model
{
    use HasFactory;
    protected $table = 'absen_pegawai';
    protected $primaryKey = 'id_absensi_pegawai';
    public $timestamps = false;
}
