<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Aktifasi Akun</title>
    <style>
        a {
            width: 200px;
            height: 200px;
            text-decoration: none;
            color: white;
            background-color: rgb(16, 228, 16);
            border-radius: 5px;
            padding: 10px;
        }
    </style>
</head>
<body>
    <h1><?php echo e($details['title']); ?></h1>
    <p>Silahkan Klik link di bawah ini untuk Aktifkan Akun Anda yang baru di daftarkan</p>
    <p><a href="<?php echo e(url('/aktifasi_akun') . '/' .$details['email']); ?>">Aktifasi Akun</a></p>
    <b>SIA | KN KEP MOROTAI 2021</b>
</body>
</html>
<?php /**PATH D:\projek\projek_4\absensi_pegawai\resources\views/page/admin/aktifasi_akun.blade.php ENDPATH**/ ?>