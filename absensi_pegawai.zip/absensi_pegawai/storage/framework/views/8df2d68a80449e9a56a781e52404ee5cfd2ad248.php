<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title><?php echo e($title); ?></title>

    <!-- Custom fonts for this template-->
    <link href="<?php echo e(url('asset/vendor/fontawesome-free/css/all.min.css')); ?>" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="<?php echo e(url('asset/css/sb-admin-2.min.css')); ?>" rel="stylesheet">
    <link rel="icon" href="<?php echo e(url('asset/img/logo.jpeg')); ?>">
    <link href="<?php echo e(url('asset/css/style.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/css/bootstrap.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.24/css/dataTables.bootstrap4.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/buttons/1.7.0/css/buttons.bootstrap4.min.css">

</head>

<body id="page-top">
    <?php if(session('status_file')): ?>
    <div id="status_file" data-flashdata="<?php echo e(session('status_file')); ?>"></div>
    <?php endif; ?>
    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="<?php echo e(url('/dashboard')); ?>">
                <div class="sidebar-brand-icon">
                    <div id="wrapper_img">
                        <img src="<?php echo e(url('asset/img') . '/' . 'icons.jpeg'); ?>" alt="">
                    </div>
                </div>
            </a>
            <div class="sidebar-brand-text mx-3 text-uppercase text-white text-center mb-3">SIA | KN KEP MOROTAI</div>

            <!-- Divider -->
            <hr class="sidebar-divider my-0">

            <li class="nav-item active">
                <a class="nav-link collapsed" href="<?php echo e(url('/pegawai')); ?>" data-toggle="collapse"
                    data-target="#collapseUtilities" aria-expanded="true" aria-controls="collapseUtilities">
                    <i class="fas fa-user-tie"></i>
                    <span>BENDAHARA</span></a>
                <div id="collapseUtilities" class="collapse" aria-labelledby="headingUtilities"
                    data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <h6 class="collapse-header">BENDAHARA</h6>
                        <a class="collapse-item active" href="<?php echo e(url('/pegawai')); ?>">PENCAIRAN</a>
                        <a class="collapse-item" href="<?php echo e(url('/slip_gaji_pegawai')); ?>">SLIP GAJI</a>
                    </div>
                </div>
            </li>

            <!-- Nav Item - Pages Collapse Menu -->
            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse"
                data-target="#pembinaan" aria-expanded="true" aria-controls="pembinaan">
                    <i class="fas fa-clipboard-list"></i>
                    <span>PEMBINAAN</span>
                </a>
                <div id="pembinaan" class="collapse" aria-labelledby="headingUtilities"
                    data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <h6 class="collapse-header">PEMBINAAN</h6>
                        <a class="collapse-item" href="<?php echo e(url('/absensi_user_pegawai') . '/' . $id); ?>">ABSENSI</a>
                        <a class="collapse-item" href="<?php echo e(url('/arsip_pegawai')); ?>">ARSIP</a>
                    </div>
                </div>
            </li>
            <li class="nav-item">
                <a class="nav-link collapsed" href="<?php echo e(url('/logout_pegawai') . '/' . $id); ?>">
                    <i class="fas fa-sign-out-alt"></i>
                    <span>LOGOUT</span>
                </a>
            </li>

        </ul>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

                    <!-- Sidebar Toggle (Topbar) -->
                    <h5 class="title_app text-uppercase">Absensi Pegawai</h5>
                    <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                        <i class="fa fa-bars"></i>
                    </button>

                    <ul class="navbar-nav ml-auto">

                        <!-- Nav Item - User Information -->
                        <li class="nav-item dropdown no-arrow">
                            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <span
                                    class="mr-2 d-none d-lg-inline text-gray-600 small text-uppercase"><?php echo e(Str::limit($nama, 7,' ')); ?></span>
                                <img class="img-profile rounded-circle" src="<?php echo e(url('asset/img') . '/' . $img); ?>" style="object-fit: cover">
                            </a>
                            <!-- Dropdown - User Information -->
                            <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in"
                                aria-labelledby="userDropdown">
                                <a class="dropdown-item" href="<?php echo e(url('/profile_pegawai') . '/' . $id); ?>">
                                    <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Profile
                                </a>
                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item" href="<?php echo e(url('/logout_pegawai') . '/' . $id); ?>">
                                    <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Logout
                                </a>
                            </div>
                        </li>

                    </ul>

                </nav>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Content Row -->
                    <div class="row">

                        <!-- Earnings (Monthly) Card Example -->
                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card border-left-primary shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                                Akun
                                            </div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo e($pengguna); ?></div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-user-alt fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Earnings (Monthly) Card Example -->
                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card border-left-success shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                                Upload File</div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800">
                                                <?php echo e($num_file); ?>

                                            </div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-file fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Earnings (Monthly) Card Example -->
                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card border-left-info shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-info text-uppercase mb-1">Absensi
                                            </div>
                                            <div class="row no-gutters align-items-center">
                                                <div class="col-auto">
                                                    <div class="h5 mb-0 mr-3 font-weight-bold text-gray-800">
                                                        <?php echo e($num_absensi); ?></div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-clipboard-list fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Pending Requests Card Example -->
                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card border-left-warning shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                                                Level
                                            </div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800">
                                                <?php if($role_id == 1): ?>
                                                <span>
                                                    ADMIN
                                                </span>
                                                <?php else: ?>
                                                <span>
                                                    PEGAWAI
                                                </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-user fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="card shadow p-3">
                        <h5>PENCAIRAN</h5>
                        <?php if($num_file): ?>
                        <div class="container_table_file" id="container_table">
                            <table class="table table-bordered display text-uppercase text-center" id="table"
                                style="width: 100%">
                                <thead>
                                    <tr style="background-color: rgb(220, 214, 214)">
                                        <td>no</td>
                                        <td>file</td>
                                        <td>status</td>
                                        <td>waktu</td>
                                        <td>keterangan</td>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $file; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $files): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td>
                                            <a href="<?php echo e(url('asset/file') . '/' . $files->file); ?>" class="btn btn-success"
                                                download="">
                                                DOWNLOAD
                                            </a>
                                        </td>
                                        <td>
                                            <?php if($files->status_file == 1): ?>
                                            <span class="badge badge-pill badge-warning">VERIFIKASI</span>
                                            <?php elseif($files->status_file == 2): ?>
                                            <span class="badge badge-pill badge-info">DI REVISI</span>
                                            <?php elseif($files->status_file == 3): ?>
                                            <span class="badge badge-pill badge-primary">SEDANG DI PROSES</span>
                                            <?php elseif($files->status_file == 4): ?>
                                            <span class="badge badge-pill badge-success">APPROVED</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php echo e($files->waktu_file); ?>

                                        </td>
                                        <td>
                                            <span class="badge pointer badge-pill badge-success" data-toggle="modal"
                                                data-target="#keterangan<?php echo e($files->id_upload_file); ?>">VIEW</span>
                                            <div class="modal fade" id="keterangan<?php echo e($files->id_upload_file); ?>"
                                                tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle"
                                                aria-hidden="true">
                                                <div class="modal-dialog modal-xl modal-dialog-centered"
                                                    role="document">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <button type="button" class="close" data-dismiss="modal"
                                                                aria-label="Close">
                                                                <span aria-hidden="true">&times;</span>
                                                            </button>
                                                        </div>
                                                        <div class="modal-body">
                                                            <embed src="<?php echo e(url('asset/file') . '/' . $files->file); ?>"
                                                                type="application/pdf" class="w-100" height="700px">
                                                            <br>
                                                            <ul class="list-group text-left">
                                                                <li class="list-group-item">
                                                                    status :
                                                                    <?php if($files->status_file == 1): ?>
                                                                    <span
                                                                        class="badge badge-pill badge-warning">VERIFIKASI</span>
                                                                    <?php elseif($files->status_file == 2): ?>
                                                                    <span class="badge badge-pill badge-info">DI
                                                                        REVISI</span>
                                                                    <?php elseif($files->status_file == 3): ?>
                                                                    <span class="badge badge-pill badge-primary">SEDANG
                                                                        DI PROSES</span>
                                                                    <?php elseif($files->status_file == 4): ?>
                                                                    <span
                                                                        class="badge badge-pill badge-success">APPROVED</span>
                                                                    <?php endif; ?>
                                                                </li>
                                                                <li class="list-group-item">
                                                                    pesan :
                                                                    <?php echo $files->keterangan; ?>

                                                                </li>
                                                                <li class="list-group-item">
                                                                    waktu : <?php echo e($files->waktu_file); ?>

                                                                </li>
                                                            </ul>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-secondary"
                                                                data-dismiss="modal">KEMBALI</button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                        <?php else: ?>
                        <div class="alert alert-success" role="alert">
                            <h4 class="alert-heading">Data Tidak Ada</h4>
                            <p>
                                Hubungi admin untuk membuat Pencairan
                            </p>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; Absensi Pegawai <?= date('Y')  ?></span>
                    </div>
                </div>
            </footer>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Bootstrap core JavaScript-->
    <script src="<?php echo e(url('asset/vendor/jquery/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(url('asset/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>

    <!-- Core plugin JavaScript-->
    <script src="<?php echo e(url('asset/vendor/jquery-easing/jquery.easing.min.js')); ?>"></script>

    <!-- Custom scripts for all pages-->
    <script src="<?php echo e(url('asset/js/sb-admin-2.min.js')); ?>"></script>

    <!-- Page level plugins -->
    <script src="<?php echo e(url('asset/vendor/chart.js/Chart.min.js')); ?>"></script>

    <script src="<?php echo e(url('asset/js/demo/chart-area-demo.js')); ?>"></script>
    <script src="<?php echo e(url('asset/js/demo/chart-pie-demo.js')); ?>"></script>
    <script src="https://cdn.ckeditor.com/ckeditor5/27.1.0/classic/ckeditor.js"></script>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.24/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.24/js/dataTables.bootstrap4.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.7.0/js/dataTables.buttons.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.7.0/js/buttons.bootstrap4.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.7.0/js/buttons.html5.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.7.0/js/buttons.print.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.7.0/js/buttons.colVis.min.js"></script>
    <script src="<?php echo e(url('asset/js/main.js')); ?>"></script>
    <script>
        $(document).ready(function () {
            var table = $('#table').DataTable({
                buttons: ['copy', 'excel', 'csv', 'print', 'pdf', 'colvis'],
                dom: "<'row'<'col-md-3'l><'col-md-5'B><'col-md-4'f>>" +
                    "<'row'<'col-md-12'tr>>" +
                    "<'row'<'col-md-5'i><'col-md-7'p>>",
                    buttons: [{
                        extend: 'print',
                        messageTop: '<b>DATA PENCAIRAN</b>',
                        exportOptions: {
                            columns: ':visible'
                        }
                    },
                    {
                        extend: 'excel',
                        extend: 'excelHtml5',
                        title: 'DATA PENCAIRAN',
                        exportOptions: {
                            columns: ':visible'
                        }
                    },
                    {
                        extend: 'pdf',
                        extend: 'pdfHtml5',
                        title: 'DATA PENCAIRAN',
                        download: 'open',
                        exportOptions: {
                            columns: ':visible'
                        }
                    },
                    'colvis'
                ]
            });

            table.buttons().container()
                .appendTo('#container_table .col-md-5:eq(0)');
        });

    </script>

</body>

</html>
<?php /**PATH D:\projek\projek_4\absensi_pegawai\resources\views/page/pegawai/index.blade.php ENDPATH**/ ?>