<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>{{ $title }}</title>

    <!-- Custom fonts for this template-->
    <link href="{{ url('asset/vendor/fontawesome-free/css/all.min.css') }}" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="{{  url('asset/css/sb-admin-2.min.css') }}" rel="stylesheet">
    <link rel="stylesheet" href="{{ url('asset/css/bootstrap-datetimepicker.min.css') }}">
    <link href="{{  url('asset/css/style.css') }}" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/css/bootstrap.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.24/css/dataTables.bootstrap4.min.css">
    <link rel="icon" href="{{ url('asset/img/logo.jpeg') }}">
    <link rel="stylesheet" href="https://cdn.datatables.net/buttons/1.7.0/css/buttons.bootstrap4.min.css">

</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

            <!-- Sidebar - Brand -->
            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="{{ url('/dashboard') }}">
                <div class="sidebar-brand-icon">
                    <div id="wrapper_img">
                        <img src="{{ url('asset/img') . '/' . 'icons.jpeg' }}" alt="">
                    </div>
                </div>
            </a>
            <div class="sidebar-brand-text mx-3 text-uppercase text-white text-center mb-3">
                SIA | KN KEP MOROTAI</div>

            <!-- Divider -->
            <hr class="sidebar-divider my-0">

            <!-- Nav Item - Dashboard -->
            <li class="nav-item">
                <a class="nav-link" style="cursor: pointer" data-toggle="collapse" data-target="#collapseUtilities"
                aria-expanded="true" aria-controls="collapseUtilities">
                    <i class="fas fa-user-tie"></i>
                    <span>BENDAHARA</span></a>
                    <div id="collapseUtilities" class="collapse" aria-labelledby="headingUtilities"
                    data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <h6 class="collapse-header">BENDAHARA</h6>
                        <a class="collapse-item" href="{{ url('/dashboard') }}">PENCAIRAN</a>
                        <a class="collapse-item" href="{{ url('/slip_gaji') }}">SLIP GAJI</a>
                    </div>
                </div>
            </li>

            <!-- Nav Item - Pages Collapse Menu -->
            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse"
                data-target="#pembinaan" aria-expanded="true" aria-controls="pembinaan">
                    <i class="fas fa-clipboard-list"></i>
                    <span>PEMBINAAN</span>
                </a>
                <div id="pembinaan" class="collapse" aria-labelledby="headingUtilities"
                    data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <h6 class="collapse-header">PEMBINAAN</h6>
                        <a class="collapse-item" href="{{ url('/absensi') }}">ABSENSI</a>
                        <a class="collapse-item" href="{{ url('/arsip') }}">ARSIP</a>
                    </div>
                </div>
            </li>
            <li class="nav-item active">
                <a class="nav-link collapsed" href="{{ url('/akun') }}" >
                    <i class="fas fa-user"></i>
                    <span>AKUN</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link collapsed" href="{{ url('/logout') . '/' . $id }}" >
                    <i class="fas fa-sign-out-alt"></i>
                    <span>LOGOUT</span>
                </a>
            </li>

        </ul>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

                    <!-- Sidebar Toggle (Topbar) -->
                    <h5 class="title_app text-uppercase">Absensi Pegawai</h5>
                    <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                        <i class="fa fa-bars"></i>
                    </button>

                    <ul class="navbar-nav ml-auto">

                        <!-- Nav Item - User Information -->
                        <li class="nav-item dropdown no-arrow">
                            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <span
                                    class="mr-2 d-none d-lg-inline text-gray-600 small text-uppercase">{{ Str::limit($nama, 7,' ') }}</span>
                                <img class="img-profile rounded-circle" src="{{ url('asset/img') . '/' . $img }}" style="object-fit: cover">
                            </a>
                            <!-- Dropdown - User Information -->
                            <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in"
                                aria-labelledby="userDropdown">
                                <a class="dropdown-item" href="{{ url('/profile') . '/' . $id }}">
                                    <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Profile
                                </a>
                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item" href="{{ url('/logout') . '/' . $id }}">
                                    <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Logout
                                </a>
                            </div>
                        </li>

                    </ul>

                </nav>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">
                    <div class="row">

                        <!-- Earnings (Monthly) Card Example -->
                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card border-left-primary shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                                Akun
                                            </div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800">{{ $num_pengguna }}</div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-user-alt fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Earnings (Monthly) Card Example -->
                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card border-left-success shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                                Upload File</div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800">
                                                {{ $num_file }}
                                            </div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-file fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Earnings (Monthly) Card Example -->
                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card border-left-info shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-info text-uppercase mb-1">Absensi
                                            </div>
                                            <div class="row no-gutters align-items-center">
                                                <div class="col-auto">
                                                    <div class="h5 mb-0 mr-3 font-weight-bold text-gray-800">{{ $num_absensi }}</div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-clipboard-list fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Pending Requests Card Example -->
                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card border-left-warning shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                                                Level</div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800">
                                                @if ($role_id == 1)
                                                        <span>
                                                            ADMIN
                                                        </span>
                                                    @else
                                                        <span>
                                                            PEGAWAI
                                                        </span>
                                                @endif
                                            </div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-user fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="container_absen_pegawai card shadow p-4">
                        <h5>PENGGUNA AKUN</h5>
                        @if ($num_pengguna)
                        <div class="kontent_tabel overflow-auto" id="container_table">
                            <table class="table display text-center text-uppercase table-bordered ml-2 mr-2" style="width: 100%" id="table">
                                <thead>
                                    <tr style="background-color: rgb(220, 214, 214)">
                                        <td>No</td>
                                        <td>Gambar</td>
                                        <td>Nama</td>
                                        <td>username</td>
                                        <td>Tanggal lahir</td>
                                        <td>Jabatan</td>
                                        <td>SATKER</td>
                                        <td>status</td>
                                        <td>Level</td>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach ($pengguna as $rows)
                                    <tr>
                                        <td>{{ $loop->iteration }}</td>
                                        <td>
                                            <div class="d-flex justify-content-center">
                                                <div class="wrapper_img">
                                                    <img src="{{ url('asset/img') . '/' . $rows->img }}" alt="">
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            {{ $rows->nama }}
                                        </td>
                                        <td>
                                            {{ $rows->username }}
                                        </td>
                                        <td>
                                            {{ $rows->tanggal_lahir }}
                                        </td>
                                        <td>
                                            {{ $rows->jabatan }}
                                        </td>
                                        <td>
                                            {{ $rows->satuan }}
                                        </td>
                                        <td>
                                            @if ($rows->is_active == 1)
                                            <span class="badge-success badge-pill badge">Aktif</span>
                                            @else
                                            <span class="badge-danger badge-pill badge">tidak Aktif</span>
                                            @endif
                                        </td>
                                        <td>
                                            @if ($rows->role_id == 1)
                                            <span class="badge-primary badge-pill badge">admin</span>
                                            @else
                                            <span class="badge-success badge-pill badge">pegawai</span>
                                            @endif
                                        </td>
                                    </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                        @else
                        <div class="alert alert-success" role="alert">
                            <h4 class="alert-heading">Data Tidak Ada</h4>
                            <p>
                                Tambahkan Akun baru terlebih dahulu
                            </p>
                          </div>
                        @endif
                    </div>
                </div>

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; Absensi Pegawai <?= date('Y')  ?></span>
                    </div>
                </div>
            </footer>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Bootstrap core JavaScript-->
    <script src="{{ url('asset/vendor/jquery/jquery.min.js') }}"></script>
    <script src="{{ url('asset/vendor/bootstrap/js/bootstrap.bundle.min.js') }}"></script>

    <!-- Core plugin JavaScript-->
    <script src="{{ url('asset/vendor/jquery-easing/jquery.easing.min.js') }}"></script>

    <!-- Custom scripts for all pages-->
    <script src="{{ url('asset/js/sb-admin-2.min.js') }}"></script>

    <!-- Page level plugins -->
    <script src="{{ url('asset/vendor/chart.js/Chart.min.js') }}"></script>

    <!-- Page level custom scripts -->
    <script src="{{ url('asset/js/demo/chart-area-demo.js') }}"></script>
    <script src="{{ url('asset/js/demo/chart-pie-demo.js') }}"></script>
    <script src="https://cdn.ckeditor.com/ckeditor5/27.1.0/classic/ckeditor.js"></script>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.24/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.24/js/dataTables.bootstrap4.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.7.0/js/dataTables.buttons.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.7.0/js/buttons.bootstrap4.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.7.0/js/buttons.html5.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.7.0/js/buttons.print.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.7.0/js/buttons.colVis.min.js"></script>
    <script src="{{ url('asset/js/bootstrap-datetimepicker.js') }}"></script>
    <script src="{{ url('asset/js/main.js') }}"></script>
    <script>
        $(document).ready(function () {
            $('#foto').on('change', function () {
                let fileName = $(this).val().split('\\').pop();
                $(this).next('.custom-file-label').addClass("selected").html(fileName);
            });

            // datetimepicker
            $('.form_datetime').datetimepicker({
                weekStart: 1,
                todayBtn: 1,
                autoclose: 1,
                todayHighlight: 1,
                startView: 2,
                forceParse: 0,
                showMeridian: false
            });

            ClassicEditor
                .create(document.querySelector('#pesan'))
                .catch(error => {
                    console.error(error);
                });

                var table = $('#table').DataTable({
                buttons: ['copy', 'excel', 'csv', 'print', 'pdf', 'colvis'],
                dom: "<'row'<'col-md-3'l><'col-md-5'B><'col-md-4'f>>" +
                    "<'row'<'col-md-12'tr>>" +
                    "<'row'<'col-md-5'i><'col-md-7'p>>",
                    buttons: [{
                        extend: 'print',
                        messageTop: '<b>DATA AKUN</b>',
                        exportOptions: {
                            columns: ':visible'
                        }
                    },
                    {
                        extend: 'excel',
                        extend: 'excelHtml5',
                        title: 'DATA AKUN',
                        exportOptions: {
                            columns: ':visible'
                        }
                    },
                    {
                        extend: 'pdf',
                        extend: 'pdfHtml5',
                        title: 'DATA AKUN',
                        download: 'open',
                        exportOptions: {
                            columns: ':visible'
                        }
                    },
                    'colvis'
                ]
            });

            table.buttons().container()
                .appendTo('#container_table .col-md-5:eq(0)');
        });

    </script>
</body>

</html>
