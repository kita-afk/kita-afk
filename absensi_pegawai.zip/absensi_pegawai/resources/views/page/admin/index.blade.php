<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>{{ $title }}</title>

    <!-- Custom fonts for this template-->
    <link href="{{ url('asset/vendor/fontawesome-free/css/all.min.css') }}" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="{{  url('asset/css/sb-admin-2.min.css') }}" rel="stylesheet">
    <link href="{{  url('asset/css/style.css') }}" rel="stylesheet">
    <link rel="icon" href="{{ url('asset/img/logo.jpeg') }}">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/css/bootstrap.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.24/css/dataTables.bootstrap4.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/buttons/1.7.0/css/buttons.bootstrap4.min.css">

</head>

<body id="page-top">
@if (session('status_file'))
    <div id="status_file" data-flashdata="{{ session('status_file') }}"></div>
@endif
    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

            <!-- Sidebar - Brand -->
            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="{{ url('/dashboard') }}">
                <div class="sidebar-brand-icon">
                    <div id="wrapper_img">
                        <img src="{{ url('asset/img') . '/' . 'icons.jpeg' }}" alt="">
                    </div>
                </div>
            </a>
            <div class="sidebar-brand-text mx-3 text-uppercase text-white text-center mb-3">SIA | KN KEP MOROTAI</div>

            <!-- Divider -->
            <hr class="sidebar-divider my-0">

            <!-- Nav Item - Dashboard -->
            <li class="nav-item active">
                <a class="nav-link" style="cursor: pointer" data-toggle="collapse" data-target="#collapseUtilities"
                aria-expanded="true" aria-controls="collapseUtilities">
                    <i class="fas fa-user-tie"></i>
                    <span>BENDAHARA</span></a>
                    <div id="collapseUtilities" class="collapse" aria-labelledby="headingUtilities"
                    data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <h6 class="collapse-header">BENDAHARA</h6>
                        <a class="collapse-item active" href="{{ url('/dashboard') }}">PENCAIRAN</a>
                        <a class="collapse-item" href="{{ url('/slip_gaji') }}">SLIP GAJI</a>
                    </div>
                </div>
            </li>

            <!-- Nav Item - Pages Collapse Menu -->
            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse"
                data-target="#pembinaan" aria-expanded="true" aria-controls="pembinaan">
                    <i class="fas fa-clipboard-list"></i>
                    <span>PEMBINAAN</span>
                </a>
                <div id="pembinaan" class="collapse" aria-labelledby="headingUtilities"
                    data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <h6 class="collapse-header">PEMBINAAN</h6>
                        <a class="collapse-item" href="{{ url('/absensi') }}">ABSENSI</a>
                        <a class="collapse-item" href="{{ url('/arsip') }}">ARSIP</a>
                    </div>
                </div>
            </li>
            <li class="nav-item">
                <a class="nav-link collapsed" href="{{ url('/akun') }}" >
                    <i class="fas fa-user"></i>
                    <span>AKUN</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link collapsed" href="{{ url('/logout') . '/' . $id }}" >
                    <i class="fas fa-sign-out-alt"></i>
                    <span>LOGOUT</span>
                </a>
            </li>

        </ul>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

                    <!-- Sidebar Toggle (Topbar) -->
                    <h5 class="title_app text-uppercase">Absensi Pegawai</h5>
                    <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                        <i class="fa fa-bars"></i>
                    </button>

                    <ul class="navbar-nav ml-auto">

                        <!-- Nav Item - User Information -->
                        <li class="nav-item dropdown no-arrow">
                            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <span class="mr-2 d-none d-lg-inline text-gray-600 small text-uppercase">{{ Str::limit($nama, 7,' ') }}</span>
                                <img class="img-profile rounded-circle"
                                    src="{{ url('asset/img') . '/' . $img }}" style="object-fit: cover">
                            </a>
                            <!-- Dropdown - User Information -->
                            <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in"
                                aria-labelledby="userDropdown">
                                <a class="dropdown-item" href="{{ url('/profile') . '/' . $id }}">
                                    <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Profile
                                </a>
                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item" href="{{ url('/logout') . '/' . $id }}" >
                                    <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Logout
                                </a>
                            </div>
                        </li>

                    </ul>

                </nav>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Content Row -->
                    <div class="row">

                        <!-- Earnings (Monthly) Card Example -->
                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card border-left-primary shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                                Akun
                                            </div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800">{{ $pengguna }}</div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-user-alt fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Earnings (Monthly) Card Example -->
                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card border-left-success shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                                Upload File</div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800">
                                                {{ $num_file }}
                                            </div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-file fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Earnings (Monthly) Card Example -->
                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card border-left-info shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-info text-uppercase mb-1">Absensi
                                            </div>
                                            <div class="row no-gutters align-items-center">
                                                <div class="col-auto">
                                                    <div class="h5 mb-0 mr-3 font-weight-bold text-gray-800">{{ $num_absensi }}</div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-clipboard-list fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Pending Requests Card Example -->
                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card border-left-warning shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                                                Level</div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800">
                                                @if ($role_id == 1)
                                                        <span>
                                                            ADMIN
                                                        </span>
                                                    @else
                                                        <span>
                                                            PEGAWAI
                                                        </span>
                                                @endif
                                            </div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-user fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="container_file card shadow mt-2">
                        <h5 class="pl-3 pt-3">PENCAIRAN</h5>
                        <div class="header_file ml-3 mt-3 mr-3">
                            <a href="{{ url('tambah_file') }}" class="btn btn-primary">
                                <i class="fas fa-plus"></i>
                                Tambah
                            </a>
                        </div>
                        <div class="ml-3 mr-3 mt-3 mb-3">
                            @if ($num_file)
                            <div class="container_table_file" id="container_table">
                                <table class="table table-bordered display text-uppercase text-center" id="table" style="width: 100%">
                                    <thead>
                                        <tr style="background-color: rgb(220, 214, 214)">
                                            <td>NO</td>
                                            <td>FILE</td>
                                            <td>STATUS</td>
                                            <td>WAKTU</td>
                                            <td>KETERANGAN</td>
                                            <td>AKSI</td>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @foreach ($file as $files)
                                            <tr>
                                                <td>{{ $loop->iteration }}</td>
                                                <td>
                                                    <a href="{{ url('asset/file') . '/' . $files->file }}" class="btn btn-success" download="">
                                                        DOWNLOAD
                                                    </a>
                                                </td>
                                                <td>
                                                    @if ($files->status_file == 1)
                                                    <span class="badge badge-pill badge-warning">VERIFIKASI</span>
                                                    @elseif ($files->status_file == 2)
                                                    <span class="badge badge-pill badge-info">DI REVISI</span>
                                                    @elseif ($files->status_file == 3)
                                                    <span class="badge badge-pill badge-primary">SEDANG DI PROSES</span>
                                                    @elseif ($files->status_file == 4)
                                                    <span class="badge badge-pill badge-success">APPROVED</span>
                                                    @endif
                                                </td>
                                                <td>
                                                    {{ $files->waktu_file }}
                                                </td>
                                                <td>
                                                    <span class="badge pointer badge-pill badge-success" data-toggle="modal"
                                                    data-target="#keterangan{{ $files->id_upload_file }}">VIEW</span>
                                                    <div class="modal fade" id="keterangan{{ $files->id_upload_file }}" tabindex="-1"
                                                        role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                                                        <div class="modal-dialog modal-xl modal-dialog-centered" role="document">
                                                            <div class="modal-content">
                                                                <div class="modal-header">
                                                                    <button type="button" class="close" data-dismiss="modal"
                                                                        aria-label="Close">
                                                                        <span aria-hidden="true">&times;</span>
                                                                    </button>
                                                                </div>
                                                                <div class="modal-body">
                                                                    <embed src="{{ url('asset/file') . '/' . $files->file }}" type="application/pdf" class="w-100" height="700px">
                                                                    <br>
                                                                    <ul class="list-group text-left">
                                                                        <li class="list-group-item">
                                                                            status :
                                                                            @if ($files->status_file == 1)
                                                                            <span class="badge badge-pill badge-warning">VERIFIKASI</span>
                                                                            @elseif ($files->status_file == 2)
                                                                            <span class="badge badge-pill badge-info">DI REVISI</span>
                                                                            @elseif ($files->status_file == 3)
                                                                            <span class="badge badge-pill badge-primary">SEDANG DI PROSES</span>
                                                                            @elseif ($files->status_file == 4)
                                                                            <span class="badge badge-pill badge-success">APPROVED</span>
                                                                            @endif
                                                                        </li>
                                                                        <li class="list-group-item">
                                                                            pesan :
                                                                            {!! $files->keterangan !!}
                                                                        </li>
                                                                        <li class="list-group-item">
                                                                            waktu : {{ $files->waktu_file }}
                                                                        </li>
                                                                    </ul>
                                                                </div>
                                                                <div class="modal-footer">
                                                                    <button type="button" class="btn btn-secondary"
                                                                        data-dismiss="modal">KEMBALI</button>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="d-flex justify-content-center pb-3">
                                                        <a href="{{ url('/edit_file') . '/' . $files->id_upload_file }}" class="btn btn-success">
                                                            <i class="fas fa-pen"></i>
                                                        </a>
                                                        @if ($files->status_file == 1 || $files->status_file == 2)
                                                        <a href="{{ url('/proses_file') . '/' . $files->id_upload_file }}" class="btn btn-primary ml-2">
                                                            <i class="fas fa-clock"></i>
                                                        </a>
                                                        @elseif($files->status_file == 3)
                                                        <a href="{{ url('/approved') . '/' . $files->id_upload_file }}" class="btn btn-primary ml-2">
                                                            <i class="fas fa-check"></i>
                                                        </a>
                                                        @elseif($files->status_file == 4)
                                                        <a href="#" class="btn btn-primary ml-2">
                                                            <i class="fas fa-check-double"></i>
                                                        </a>
                                                        @endif
                                                        <form action="{{ url('/hapus_file') . '/' . $files->id_upload_file }}" class="ml-2" method="POST">
                                                                @method('delete')
                                                                @csrf
                                                                <button type="submit" class="btn btn-danger">
                                                                    <i class="fas fa-trash"></i>
                                                                </button>
                                                        </form>
                                                    </div>
                                                </td>
                                            </tr>
                                        @endforeach
                                    </tbody>
                                </table>
                            </div>
                            @else
                            <div class="alert alert-success" role="alert">
                                <h4 class="alert-heading">Data Tidak Ada</h4>
                                <p>
                                    Pilih Tombol Tambah untuk menambahkan file baru
                                </p>
                            </div>
                            @endif
                        </div>
                    </div>

                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; Absensi Pegawai <?= date('Y')  ?></span>
                    </div>
                </div>
            </footer>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Bootstrap core JavaScript-->
    <script src="{{ url('asset/vendor/jquery/jquery.min.js') }}"></script>
    <script src="{{ url('asset/vendor/bootstrap/js/bootstrap.bundle.min.js') }}"></script>

    <!-- Core plugin JavaScript-->
    <script src="{{ url('asset/vendor/jquery-easing/jquery.easing.min.js') }}"></script>

    <!-- Custom scripts for all pages-->
    <script src="{{ url('asset/js/sb-admin-2.min.js') }}"></script>

    <!-- Page level plugins -->
    <script src="{{ url('asset/vendor/chart.js/Chart.min.js') }}"></script>

    <!-- Page level custom scripts -->
    <script src="{{ url('asset/js/demo/chart-area-demo.js') }}"></script>
    <script src="{{ url('asset/js/demo/chart-pie-demo.js') }}"></script>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <script src="https://cdn.ckeditor.com/ckeditor5/27.1.0/classic/ckeditor.js"></script>
    <script src="https://cdn.datatables.net/1.10.24/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.24/js/dataTables.bootstrap4.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.7.0/js/dataTables.buttons.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.7.0/js/buttons.bootstrap4.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.7.0/js/buttons.html5.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.7.0/js/buttons.print.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.7.0/js/buttons.colVis.min.js"></script>
    <script src="{{ url('asset/js/main.js') }}"></script>
    <script>
        $(document).ready(function () {
            var table = $('#table').DataTable({
                buttons: ['copy', 'excel', 'csv', 'print', 'pdf', 'colvis'],
                dom: "<'row'<'col-md-3'l><'col-md-5'B><'col-md-4'f>>" +
                    "<'row'<'col-md-12'tr>>" +
                    "<'row'<'col-md-5'i><'col-md-7'p>>",
                buttons: [{
                        extend: 'print',
                        messageTop: '<b>DATA PENCAIRAN</b>',
                        exportOptions: {
                            columns: ':visible'
                        }
                    },
                    {
                        extend: 'excel',
                        extend: 'excelHtml5',
                        title: 'DATA PENCAIRAN',
                        exportOptions: {
                            columns: ':visible'
                        }
                    },
                    {
                        extend: 'pdf',
                        extend: 'pdfHtml5',
                        title: 'DATA PENCAIRAN',
                        download: 'open',
                        exportOptions: {
                            columns: [ 0, 1, 2, 5 ]
                        }
                    },
                    'colvis'
                ]
            });

            table.buttons().container()
                .appendTo('#container_table .col-md-5:eq(0)');
        });

    </script>

</body>

</html>
