<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>{{ $title }}</title>

    <!-- Custom fonts for this template-->
    <link href="{{ url('asset/vendor/fontawesome-free/css/all.min.css') }}" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="{{  url('asset/css/sb-admin-2.min.css') }}" rel="stylesheet">
    <link rel="stylesheet" href="{{ url('asset/css/bootstrap-datetimepicker.min.css') }}">
    <link href="{{  url('asset/css/style.css') }}" rel="stylesheet">
    <link rel="icon" href="{{ url('asset/img/logo.jpeg') }}">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/css/bootstrap.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.24/css/dataTables.bootstrap4.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/buttons/1.7.0/css/buttons.bootstrap4.min.css">

</head>

<body id="page-top">
    @if (session('status_profile'))
        <div id="status_profile" data-flashdata="{{ session('status_profile') }}"></div>
    @endif

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

            <!-- Sidebar - Brand -->
            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="{{ url('/dashboard') }}">
                <div class="sidebar-brand-icon">
                    <div id="wrapper_img">
                        <img src="{{ url('asset/img') . '/' . 'icons.jpeg' }}" alt="">
                    </div>
                </div>
            </a>
            <div class="sidebar-brand-text mx-3 text-uppercase text-white text-center mb-3">
                SIA | KN KEP MOROTAI</div>

            <!-- Divider -->
            <hr class="sidebar-divider my-0">

            <!-- Nav Item - Dashboard -->
            <li class="nav-item">
                <a class="nav-link" style="cursor: pointer" data-toggle="collapse" data-target="#collapseUtilities"
                aria-expanded="true" aria-controls="collapseUtilities">
                    <i class="fas fa-user-tie"></i>
                    <span>BENDAHARA</span></a>
                    <div id="collapseUtilities" class="collapse" aria-labelledby="headingUtilities"
                    data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <h6 class="collapse-header">BENDAHARA</h6>
                        <a class="collapse-item" href="{{ url('/dashboard') }}">PENCAIRAN</a>
                        <a class="collapse-item" href="{{ url('/slip_gaji') }}">SLIP GAJI</a>
                    </div>
                </div>
            </li>

            <!-- Nav Item - Pages Collapse Menu -->
            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse"
                data-target="#pembinaan" aria-expanded="true" aria-controls="pembinaan">
                    <i class="fas fa-clipboard-list"></i>
                    <span>PEMBINAAN</span>
                </a>
                <div id="pembinaan" class="collapse" aria-labelledby="headingUtilities"
                    data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <h6 class="collapse-header">PEMBINAAN</h6>
                        <a class="collapse-item" href="{{ url('/absensi') }}">ABSENSI</a>
                        <a class="collapse-item" href="{{ url('/arsip') }}">ARSIP</a>
                    </div>
                </div>
            </li>
            <li class="nav-item">
                <a class="nav-link collapsed" href="{{ url('/akun') }}" >
                    <i class="fas fa-user"></i>
                    <span>AKUN</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link collapsed" href="{{ url('/logout') . '/' . $id }}" >
                    <i class="fas fa-sign-out-alt"></i>
                    <span>LOGOUT</span>
                </a>
            </li>

        </ul>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

                    <!-- Sidebar Toggle (Topbar) -->
                    <h5 class="title_app text-uppercase">Absensi Pegawai</h5>
                    <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                        <i class="fa fa-bars"></i>
                    </button>

                    <ul class="navbar-nav ml-auto">

                        <!-- Nav Item - User Information -->
                        <li class="nav-item dropdown no-arrow">
                            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <span
                                    class="mr-2 d-none d-lg-inline text-gray-600 small text-uppercase">{{ Str::limit($nama, 7,' ') }}</span>
                                <img class="img-profile rounded-circle" src="{{ url('asset/img') . '/' . $img }}" style="object-fit: cover">
                            </a>
                            <!-- Dropdown - User Information -->
                            <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in"
                                aria-labelledby="userDropdown">
                                <a class="dropdown-item" href="{{ url('/profile') . '/' . $id }}">
                                    <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Profile
                                </a>
                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item" href="{{ url('/logout') . '/' . $id }}">
                                    <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Logout
                                </a>
                            </div>
                        </li>

                    </ul>

                </nav>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <div class="container_profile_user card shadow">
                        <h4 class="ml-3 mt-2">Akun</h4>
                        <div class="kontent-contanier-user m-3">
                            <div class="row_1">
                                <div class="card shadow">
                                    <div class="d-flex justify-content-center">
                                        <div class="wrapper_profile mt-3 mb-3">
                                            <img src="{{ url('asset/img') . '/' . $pengguna->img }}" alt="">
                                        </div>
                                    </div>
                                    <ul class="list-group text-uppercase">
                                        <li class="list-group-item">nama : {{ $pengguna->nama }}</li>
                                        <li class="list-group-item">username : {{ $pengguna->username }}</li>
                                        <li class="list-group-item">tanggal lahir : {{ $pengguna->tanggal_lahir }}</li>
                                        <li class="list-group-item">level :
                                            @if ($pengguna->role_id == 1)
                                                Admin
                                            @else
                                                Pegawai
                                            @endif
                                        </li>
                                        <li class="list-group-item">
                                            status :
                                            @if ($pengguna->is_active == 1)
                                                <span class="badge badge-pill badge-success">aktif</span>
                                                @else
                                                <span class="badge badge-pill badge-danger">tidak aktif</span>
                                            @endif
                                        </li>
                                      </ul>
                                </div>
                            </div>
                            <div class="row_1">
                                <form action="{{ url('/simpan_profile') . '/' . $pengguna->id_pengguna }}" method="POST" enctype="multipart/form-data">
                                    @csrf
                                    <input type="hidden" name="gambar_lama" value="{{ $pengguna->img }}">
                                    <div class="form-group row">
                                        <label for="password_lama" class="col-sm-2 col-form-label">Password Lama</label>
                                        <div class="col-sm-10">
                                            <div class="custom-file">
                                                <input type="password" name="password_lama" id="password_lama" value="" class="form-control @error('password_lama')
                                            is-invalid
                                            @enderror" placeholder="Password Lama">
                                                @error('password_lama')
                                                <small class="text-danger">{{ $message }}</small>
                                                @enderror
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="password_baru" class="col-sm-2 col-form-label">Password Baru</label>
                                        <div class="col-sm-10">
                                            <div class="custom-file">
                                                <input type="password" name="password_baru" id="password_baru" value="" class="form-control @error('password_baru')
                                            is-invalid
                                            @enderror" placeholder="Password Lama">
                                                @error('password_baru')
                                                <small class="text-danger">{{ $message }}</small>
                                                @enderror
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="ulangi_password" class="col-sm-2 col-form-label">Ulangi Password</label>
                                        <div class="col-sm-10">
                                            <div class="custom-file">
                                                <input type="password" name="ulangi_password" id="ulangi_password" value="" class="form-control @error('ulangi_password')
                                            is-invalid
                                            @enderror" placeholder="Ulangi Password Baru">
                                                @error('ulangi_password')
                                                <small class="text-danger">{{ $message }}</small>
                                                @enderror
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="foto" class="col-sm-2 col-form-label">Gambar</label>
                                        <div class="col-sm-10">
                                            <div class="custom-file">
                                                <input type="file" class="custom-file-input @error('img')
                                                    is-invalid
                                                @enderror" id="foto" name="img">
                                                <label class="custom-file-label" for="validatedCustomFile">Choose file...</label>
                                                @error('img')
                                                    <small class="text-danger">{{ $message }}</small>
                                                @enderror
                                            </div>
                                            <small class="text-secondary cambira">Suport file Jpg,Png,jpeg</small>
                                        </div>
                                    </div>
                                    <a href="{{ url('/dashboard') }}" class="btn btn-dark">
                                    BATAL</a>
                                    <button type="submit" class="btn btn-primary">SIMPAN</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; Absensi Pegawai <?= date('Y')  ?></span>
                    </div>
                </div>
            </footer>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Bootstrap core JavaScript-->
    <script src="{{ url('asset/vendor/jquery/jquery.min.js') }}"></script>
    <script src="{{ url('asset/vendor/bootstrap/js/bootstrap.bundle.min.js') }}"></script>

    <!-- Core plugin JavaScript-->
    <script src="{{ url('asset/vendor/jquery-easing/jquery.easing.min.js') }}"></script>

    <!-- Custom scripts for all pages-->
    <script src="{{ url('asset/js/sb-admin-2.min.js') }}"></script>

    <!-- Page level plugins -->
    <script src="{{ url('asset/vendor/chart.js/Chart.min.js') }}"></script>

    <!-- Page level custom scripts -->
    <script src="{{ url('asset/js/demo/chart-area-demo.js') }}"></script>
    <script src="{{ url('asset/js/demo/chart-pie-demo.js') }}"></script>
    <script src="https://cdn.ckeditor.com/ckeditor5/27.1.0/classic/ckeditor.js"></script>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.24/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.24/js/dataTables.bootstrap4.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.7.0/js/dataTables.buttons.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.7.0/js/buttons.bootstrap4.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.7.0/js/buttons.html5.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.7.0/js/buttons.print.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.7.0/js/buttons.colVis.min.js"></script>
    <script src="{{ url('asset/js/bootstrap-datetimepicker.js') }}"></script>
    <script src="{{ url('asset/js/main.js') }}"></script>
    <script>
        $(document).ready(function () {
            $('#foto').on('change', function () {
                let fileName = $(this).val().split('\\').pop();
                $(this).next('.custom-file-label').addClass("selected").html(fileName);
            });

            // datetimepicker
            $('.form_datetime').datetimepicker({
                weekStart: 1,
                todayBtn: 1,
                autoclose: 1,
                todayHighlight: 1,
                startView: 2,
                forceParse: 0,
                showMeridian: false
            });

            ClassicEditor
                .create(document.querySelector('#pesan'))
                .catch(error => {
                    console.error(error);
                });

                var table = $('#table').DataTable({
                buttons: ['copy', 'excel', 'csv', 'print', 'pdf', 'colvis'],
                dom: "<'row'<'col-md-3'l><'col-md-5'B><'col-md-4'f>>" +
                    "<'row'<'col-md-12'tr>>" +
                    "<'row'<'col-md-5'i><'col-md-7'p>>",
                buttons: [{
                        extend: 'print',
                        messageTop: '<b>DATA AKUN</b>',
                    },
                    {
                        extend: 'excel',
                        messageTop: '<b>DATA AKUN</b>',
                        extend: 'excelHtml5',
                        title: 'DATA AKUN'
                    },
                    {
                        extend: 'pdf',
                        extend: 'pdfHtml5',
                        title: 'DATA AKUN',
                        download: 'open'
                    },
                    {
                        extend: 'copy'
                    },
                    {
                        extend: 'csv',
                    }
                ]
            });

            table.buttons().container()
                .appendTo('#container_table .col-md-5:eq(0)');
        });

    </script>
</body>

</html>
