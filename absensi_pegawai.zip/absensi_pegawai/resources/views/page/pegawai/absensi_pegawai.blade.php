<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>{{ $title }}</title>

    <!-- Custom fonts for this template-->
    <link href="{{ url('asset/vendor/fontawesome-free/css/all.min.css') }}" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="{{  url('asset/css/sb-admin-2.min.css') }}" rel="stylesheet">
    <link rel="icon" href="{{ url('asset/img/logo.jpeg') }}">
    <link href="{{  url('asset/css/style.css') }}" rel="stylesheet">

</head>

<body id="page-top">
    @if (session('status_file'))
    <div id="status_file" data-flashdata="{{ session('status_file') }}"></div>
    @endif
    @if (session('token'))
    <div id="token" data-flashdata="{{ session('token') }}"></div>
    @endif
    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

            <!-- Sidebar - Brand -->
            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="{{ url('/dashboard') }}">
                <div class="sidebar-brand-icon">
                    <div id="wrapper_img">
                        <img src="{{ url('asset/img') . '/' . 'icons.jpeg' }}" alt="">
                    </div>
                </div>
            </a>
            <div class="sidebar-brand-text mx-3 text-uppercase text-white text-center mb-3">SIA | KN KEP MOROTAI</div>

            <!-- Divider -->
            <hr class="sidebar-divider my-0">

            <li class="nav-item">
                <a class="nav-link collapsed" href="{{ url('/pegawai') }}" data-toggle="collapse" data-target="#collapseUtilities"
                aria-expanded="true" aria-controls="collapseUtilities">
                    <i class="fas fa-user-tie"></i>
                    <span>BENDAHARA</span></a>
                    <div id="collapseUtilities" class="collapse" aria-labelledby="headingUtilities"
                    data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <h6 class="collapse-header">BENDAHARA</h6>
                        <a class="collapse-item" href="{{ url('/pegawai') }}">PENCAIRAN</a>
                        <a class="collapse-item" href="{{ url('/slip_gaji_pegawai') }}">SLIP GAJI</a>
                    </div>
                </div>
            </li>

            <!-- Nav Item - Pages Collapse Menu -->
            <li class="nav-item active">
                <a class="nav-link collapsed" href="#" data-toggle="collapse"
                data-target="#pembinaan" aria-expanded="true" aria-controls="pembinaan">
                    <i class="fas fa-clipboard-list"></i>
                    <span>PEMBINAAN</span>
                </a>
                <div id="pembinaan" class="collapse" aria-labelledby="headingUtilities"
                    data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <h6 class="collapse-header">PEMBINAAN</h6>
                        <a class="collapse-item active" href="{{ url('/absensi_user_pegawai') . '/' . $id }}">ABSENSI</a>
                        <a class="collapse-item" href="{{ url('/arsip_pegawai') }}">ARSIP</a>
                    </div>
                </div>
            </li>
            <li class="nav-item">
                <a class="nav-link collapsed" href="{{ url('/logout_pegawai') . '/' . $id }}">
                    <i class="fas fa-sign-out-alt"></i>
                    <span>LOGOUT</span>
                </a>
            </li>

        </ul>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

                    <!-- Sidebar Toggle (Topbar) -->
                    <h5 class="title_app text-uppercase">Absensi Pegawai</h5>
                    <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                        <i class="fa fa-bars"></i>
                    </button>

                    <ul class="navbar-nav ml-auto">

                        <!-- Nav Item - User Information -->
                        <li class="nav-item dropdown no-arrow">
                            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <span
                                    class="mr-2 d-none d-lg-inline text-gray-600 small text-uppercase">{{ Str::limit($nama, 7,' ') }}</span>
                                <img class="img-profile rounded-circle" src="{{ url('asset/img') . '/' . $img }}" style="object-fit: cover">
                            </a>
                            <!-- Dropdown - User Information -->
                            <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in"
                                aria-labelledby="userDropdown">
                                <a class="dropdown-item" href="{{ url('/profile_pegawai') . '/' . $id }}">
                                    <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Profile
                                </a>
                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item" href="{{ url('/logout_pegawai') . '/' . $id }}">
                                    <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Logout
                                </a>
                            </div>
                        </li>

                    </ul>

                </nav>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Content Row -->
                    <div class="row">

                        <!-- Earnings (Monthly) Card Example -->
                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card border-left-primary shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                                Akun
                                            </div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800">{{ $pengguna }}</div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-user-alt fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Earnings (Monthly) Card Example -->
                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card border-left-success shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                                Upload File</div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800">
                                                {{ $num_file }}
                                            </div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-file fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Earnings (Monthly) Card Example -->
                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card border-left-info shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-info text-uppercase mb-1">Absensi
                                            </div>
                                            <div class="row no-gutters align-items-center">
                                                <div class="col-auto">
                                                    <div class="h5 mb-0 mr-3 font-weight-bold text-gray-800">
                                                        {{ $num_absensi }}</div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-clipboard-list fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Pending Requests Card Example -->
                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card border-left-warning shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                                                Level</div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800">
                                                @if ($role_id == 1)
                                                <span>
                                                    ADMIN
                                                </span>
                                                @else
                                                <span>
                                                    PEGAWAI
                                                </span>
                                                @endif
                                            </div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-user fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="container_from_absen card  shadow p-4">
                        <form action="{{ url('/izin_masuk') . '/' . $id_absensi_pegawai . '/absen_id' . '/' . $id_absen  }}" method="POST" enctype="multipart/form-data">
                            @csrf
                            <h5>ABSEN PEGAWAI</h5>
                            <input type="hidden" name="pengguna_id" value="{{ $id }}">
                            <input type="hidden" name="absen_id" value="{{ $id_absensi_pegawai }}">
                            <div class="form-group row">
                                <label for="judul" class="col-sm-2 col-form-label">Judul</label>
                                <div class="col-sm-10">
                                    <input type="text" id="judul" name="judul" value="{{ $data_pegawai_absen->judul }}" class="form-control" readonly>
                                    @error('judul')
                                        <small class="text-danger">{{ $message }}</small>
                                    @enderror
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="alasan" class="col-sm-2 col-form-label">Alasan</label>
                                <div class="col-sm-10">
                                    <select name="alasan" id="alasan" class="form-control @error('alasan')
                                        is-invalid
                                    @enderror">
                                        <option value="1">IZIN</option>
                                        <option value="2">SAKIT</option>
                                        <option value="3">DINAS LUAR</option>
                                        <option value="4">TANPA KETERANGAN</option>
                                        <option value="5">TELAT</option>
                                        <option value="7">CUTI</option>
                                    </select>
                                    @error('alasan')
                                        <small class="text-danger">{{ $message }}</small>
                                    @enderror
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="foto" class="col-sm-2 col-form-label">File</label>
                                <div class="col-sm-10">
                                    <div class="custom-file">
                                        <input type="file" class="custom-file-input @error('file')
                                            is-invalid
                                        @enderror" id="foto" name="file">
                                        <label class="custom-file-label" for="validatedCustomFile">Choose file...</label>
                                        @error('file')
                                            <small class="text-danger">{{ $message }}</small>
                                        @enderror
                                    </div>
                                    <small class="text-secondary cambira">Suport file Pdf</small>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="token" class="col-sm-2 col-form-label">Token</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control @error('token')
                                        is-invalid
                                    @enderror" name="token" value="{{ old('token') }}" placeholder="Token">
                                    @error('token')
                                        <small class="text-danger">{{ $message }}</small>
                                    @enderror
                                    <div class="alert mt-3 alert-primary" role="alert">
                                        <h5>TOKEN :
                                            @if (!$data_token)
                                                TOKEN TIDAK ADA
                                            @else
                                            <?= $data_token['token'] ?>
                                            @endif
                                        </h5>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="pesan" class="col-sm-2 col-form-label">Pesan</label>
                                <div class="col-sm-10">
                                    <textarea name="pesan" class="form-control" id="pesan" cols="10" rows="5">
                                        {{ old('pesan') }}
                                    </textarea>
                                    @error('pesan')
                                    <small class="text-danger">{{ $message }}</small>
                                    @enderror
                                    <br>
                                    <button type="submit" class="btn btn-primary">KIRIM</button>
                                </div>
                            </div>
                        </form>
                        <div class="form">
                            <a href="{{ url('/absensi_user_pegawai') . '/' . $id }}" class="btn btn-dark">
                                Batal
                            </a>
                            <span class="btn btn-success" data-toggle="modal" data-target="#masuk">
                                Masuk
                            </span>
                            <div class="modal fade" id="masuk" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                                <div class="modal-dialog modal-xl modal-dialog-centered" role="document">
                                  <div class="modal-content">
                                    <div class="modal-header">
                                      <h5 class="modal-title text-uppercase" id="masukTitle">{{ $data_pegawai_absen->judul }}</h5>
                                      <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                      </button>
                                    </div>
                                    <div class="modal-body">
                                      <form action="{{ url('/masuk') . '/' . $id_absensi_pegawai . '/absen_id' . '/'  . $id_absen }}" method="POST">
                                        @csrf
                                        <input type="hidden" name="pengguna_id" value="{{ $id }}">
                                        <input type="hidden" name="absen_id" value="{{ $id_absensi_pegawai }}">
                                        <div class="form-group row">
                                            <label for="token" class="col-sm-2 col-form-label">Token</label>
                                            <div class="col-sm-10">
                                                <input type="text" class="form-control @error('token')
                                                    is-invalid
                                                @enderror" name="token" value="{{ old('token') }}" placeholder="Token">
                                                @error('token')
                                                    <small class="text-danger">{{ $message }}</small>
                                                @enderror
                                                <div class="alert mt-3 alert-primary" role="alert">
                                                    <h5>TOKEN :
                                                        @if (!$data_token)
                                                            TOKEN TIDAK ADA
                                                        @else
                                                        <?= $data_token['token'] ?>
                                                        @endif
                                                    </h5>
                                                </div>
                                                <button  class="btn btn-success">MASUK</button>
                                            </div>
                                        </div>
                                      </form>
                                    </div>
                                    <div class="modal-footer">
                                      <button type="button" class="btn btn-secondary" data-dismiss="modal">KEMBALI</button>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                    </div>
    </div>

    </div>

    <!-- Footer -->
    <footer class="sticky-footer bg-white">
        <div class="container my-auto">
            <div class="copyright text-center my-auto">
                <span>Copyright &copy; Absensi Pegawai <?= date('Y')  ?></span>
            </div>
        </div>
    </footer>
    <!-- End of Footer -->

    </div>
    <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Bootstrap core JavaScript-->
    <script src="{{ url('asset/vendor/jquery/jquery.min.js') }}"></script>
    <script src="{{ url('asset/vendor/bootstrap/js/bootstrap.bundle.min.js') }}"></script>

    <!-- Core plugin JavaScript-->
    <script src="{{ url('asset/vendor/jquery-easing/jquery.easing.min.js') }}"></script>

    <!-- Custom scripts for all pages-->
    <script src="{{ url('asset/js/sb-admin-2.min.js') }}"></script>

    <!-- Page level plugins -->
    <script src="{{ url('asset/vendor/chart.js/Chart.min.js') }}"></script>

    <!-- Page level custom scripts -->
    <script src="{{ url('asset/js/demo/chart-area-demo.js') }}"></script>
    <script src="{{ url('asset/js/demo/chart-pie-demo.js') }}"></script>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    {{-- <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script> --}}
    <script src="https://cdn.ckeditor.com/ckeditor5/27.1.0/classic/ckeditor.js"></script>
    <script src="{{ url('asset/js/main.js') }}"></script>
    <script>
        $(document).ready(function () {
            $('#foto').on('change', function () {
                let fileName = $(this).val().split('\\').pop();
                $(this).next('.custom-file-label').addClass("selected").html(fileName);
            });

            $('#refersh').on('click',function() {
                document.location.reload();
            });

            ClassicEditor
                .create(document.querySelector('#pesan'))
                .catch(error => {
                    console.error(error);
                });
        });

    </script>
</body>

</html>
